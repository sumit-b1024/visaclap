<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
     <?php if($franchisdetail[0]->title != ""){ ?>
        <title><?=$franchisdetail[0]->title?></title>
    <?php } ?>
    <?php if($franchisdetail[0]->keywords != ""){ ?>
    <meta name="keywords" content="<?=$franchisdetail[0]->keywords?>">
    <?php } ?> 
    <?php if($franchisdetail[0]->description != ""){ ?>
    <meta name="description" content="<?=$franchisdetail[0]->description?>">
    <?php } ?>    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.2/assets/css/docs.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
    <!-- MDB -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.0.0/mdb.min.css" rel="stylesheet" />
        
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>assets/fronted/style.css">
    <link rel="stylesheet" href="assets/slider/swiper-bundle.min.css">
    <script src="<?php echo base_url(); ?>assets/fronted/swiper-bundle.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/fronted/main.js"></script>

    <script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
</head>

<body class="m-0 border-0">
    <!-- Example Code -->
    <div class="accordion" id="accordionExample">
        <div class="accordion-item">
            <nav class="navbar sticky-top navbar-expand-xl bg-light">
                <div class="container-fluid">
                    <a class="navbar-brand fw-bold ms-3" href="#">
                    	<?php if($franchisdetail[0]->logo != ""){ ?>
                    		<img src="<?php echo base_url().$franchisdetail[0]->logo ?>" width="50" height="60" />
                    	<?php }else{ ?>	
                    		LOGO
                    	<?php } ?>	
                    </a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse-md navbar-collapse-sm navbar-collapse"
                        id="navbarSupportedContent">
                        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                            <li class="nav-item  my-auto">
                                <a class="nav-link active" aria-current="page" href="#">
                                    <button class="btn px-1 shadow-none nav-button">
                                        <i class="fa-solid fa-house-chimney pe-0"></i> Home
                                    </button>
                                </a>
                            </li>
                            <li class="nav-item  my-auto py-2">
                                <div class="dropdown">
                                    <button class="btn px-2 bg-light nav-button dropdown-toggle shadow-none my-auto"
                                        type="button" id="dropdownMenuButton" data-mdb-toggle="dropdown"
                                        aria-expanded="false">
                                        Free Zone Companies
                                    </button>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <li>
                                            <a class="dropdown-item" href="#">
                                                <div class="row">
                                                    <div class="col-6">Option 1</div>
                                                    <div class="col-6 text-end"> &rsaquo;</div>
                                                </div>
                                            </a>
                                            <ul class="dropdown-menu dropdown-submenu">
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 1</a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 2</a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 3</a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 4</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="#">
                                                <div class="row">
                                                    <div class="col-6">Option 2</div>
                                                    <div class="col-6 text-end"> &rsaquo;</div>
                                                </div>
                                            </a>
                                            <ul class="dropdown-menu dropdown-submenu">


                                                <li>
                                                    <a class="dropdown-item" href="#">Option 1</a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 2</a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 3</a>
                                                </li>

                                                <li>
                                                    <a class="dropdown-item" href="#">Option 4
                                                    </a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="#">
                                                <div class="row">
                                                    <div class="col-6">Option 3</div>
                                                    <div class="col-6 text-end"> &rsaquo;</div>
                                                </div>
                                            </a>
                                            <ul class="dropdown-menu dropdown-submenu">

                                                <li>
                                                    <a class="dropdown-item" href="#">Option 1</a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 2
                                                    </a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 3
                                                    </a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 4
                                                    </a>
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item  my-auto py-2">
                                <div class="dropdown">
                                    <button class="btn px-2 bg-light nav-button dropdown-toggle shadow-none my-auto"
                                        type="button" id="dropdownMenuButton" data-mdb-toggle="dropdown"
                                        aria-expanded="false">
                                        USA Food
                                    </button>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <li>
                                            <a class="dropdown-item" href="#">
                                                <div class="row">
                                                    <div class="col-6">Option 1</div>
                                                    <div class="col-6 text-end"> &rsaquo;</div>
                                                </div>
                                            </a>
                                            <ul class="dropdown-menu dropdown-submenu">
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 1</a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 2</a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 3</a>
                                                </li>

                                                <li>
                                                    <a class="dropdown-item" href="#">Option 4</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="#">
                                                <div class="row">
                                                    <div class="col-6">Option 2</div>
                                                    <div class="col-6 text-end"> &rsaquo;</div>
                                                </div>
                                            </a>
                                            <ul class="dropdown-menu dropdown-submenu">
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 1</a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 2</a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 3</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="#">
                                                <div class="row">
                                                    <div class="col-6">Option 3</div>
                                                    <div class="col-6 text-end"> &rsaquo;</div>
                                                </div>
                                            </a>
                                            <ul class="dropdown-menu dropdown-submenu">

                                                <li>
                                                    <a class="dropdown-item" href="#">Option 1</a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 2
                                                    </a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 3
                                                    </a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 4
                                                    </a>
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item  my-auto">
                                <a class="nav-link " aria-current="page" href="#">
                                    <button class="btn px-1 nav-button shadow-none">
                                        About
                                    </button>
                                </a>
                            </li>
                            <li class="nav-item  my-auto">
                                <a class="nav-link " aria-current="page" href="#">
                                    <button class="btn px-1 nav-button shadow-none">
                                        Contact
                                    </button>
                                </a>
                            </li>
                            <li class="nav-item  my-auto">
                                <a class="nav-link " aria-current="page" href="#">
                                    <button class="btn px-1 nav-button shadow-none">
                                        Privacy Policy
                                    </button>
                                </a>
                            </li>
                            
                                        
                                <?php if($franchisdetail[0]->coustmer_number != ""){ ?>
                                    <li class="nav-item  my-auto">
                                        <a class="nav-link " aria-current="page" href="tel:<?php echo $franchisdetail[0]->coustmer_number ?>">
                                                <button class="btn px-1 nav-button  shadow-none">
                                                    <?php echo "Call on ".$franchisdetail[0]->coustmer_number ?>
                                              </button>
                                        </a>
                                    </li>
                                <?php } ?>  
                            <li class="nav-item  my-auto">
                                <button class=" btn px-1 bg-light nav-button shadow-none collapsed"
                                    onclick="expandCollapseExpansionPanel()" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                                    <i class="fa-solid fa-magnifying-glass me-2"></i>Search
                                </button>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <div id="collapseTwo" class="accordion-collapse collapse h-100" aria-labelledby="headingOne"
                data-bs-parent="#accordionExample">
                <div class="accordion-body">
                    <div class="row">
                        <div class="col-md-8 offset-md-2">
                            <h1 class="text-center text-secondary my-3">SEARCH</h1>
                            <div class="input-group mt-3">
                                <input type="text" class="form-control border-0 "
                                    placeholder="Search stories, places and people"
                                    aria-label="Search stories, places and people" aria-describedby="basic-addon2">
                                <div class="input-group-append">
                                    <span class="input-group-text border-0 " id="basic-addon2">
                                        <i class="fa-solid fa-magnifying-glass me-2"></i>
                                    </span>
                                </div>
                            </div>
                            <hr class="border-4 border-dark my-0">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <section id="carousel">
        <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="false">

            <div class="carousel-inner rounded-0">
                <div class="carousel-item   rounded-0 active " style="height: 450px;">
                    <?php if($franchisdetail[0]->home_bg != ""){ ?>
                    <img src="<?= base_url().$franchisdetail[0]->home_bg; ?>"
                        class="d-block w-100 carousel-img" alt="...">
                     <?php }else{ ?>   
                        <img src="https://cdn.pixabay.com/photo/2019/03/09/21/30/downtown-4045036_1280.jpg"
                        class="d-block w-100 carousel-img" alt="...">
                     <?php } ?>   
                    <div class="carousel-caption text-center text-white  ">
                        <div class="carousel-body  text-center w-100  ">
                            <h1 class="text-white mainheader"
                                style="font-size: 50px; font-family: 'Jost',sans-serif; font-weight:600;">
                                Find
                                Next
                                Place To Visit
                            </h1>
                            <h5 class="text-white">Discover amzaing places at exclusive deals
                            </h5>


                            <div class="container-fluid mt-2">
                                <div class="d-block">
                                    <ul class="nav nav-tabs justify-content-between tabs-header mb-3 flex-row  
                                         flex-nowrap overflow-scroll" id="myTab" role="tablist">
                                        <li class="nav-item " role="presentation">
                                            <button id="today-tab"
                                                class="nav-link  text-white w-100 h-100 text-nowrap cursor-pointer position-relative  active"
                                                id="hotel-tab" data-bs-toggle="tab" data-bs-target="#hotel"
                                                type="button" role="tab" aria-controls=""
                                                onclick="swichTab('guest-in-hotel-tab')"
                                                aria-selected="true">Hotel</button>
                                        </li>
                                        <li class="nav-item " role="presentation">
                                            <button
                                                class="nav-link  text-white w-100 h-100 text-nowrap cursor-pointer position-relative  "
                                                id="tour-tab" data-bs-toggle="tab" data-bs-target="#tour" type="button"
                                                role="tab" aria-controls="" onclick="swichTab('guest-in-tour-tab')"
                                                aria-selected="false">Tour</button>
                                        </li>
                                        <li class="nav-item " role="presentation">
                                            <button
                                                class="nav-link  text-white w-100 h-100 text-nowrap cursor-pointer position-relative  "
                                                id="activity-tab" data-bs-toggle="tab" data-bs-target="#activity"
                                                type="button" role="tab" aria-controls=""
                                                onclick="swichTab('guest-in-activity-tab')" aria-selected="false">
                                                Activity</button>
                                        </li>
                                        <li class="nav-item " role="presentation">
                                            <button
                                                class="nav-link  text-white w-100 h-100 text-nowrap cursor-pointer position-relative  "
                                                id="holiday-rentals-tab" data-bs-toggle="tab"
                                                data-bs-target="#holiday-rentals" type="button" role="tab"
                                                aria-controls="" onclick="swichTab('guest-in-holidayrentals-tab')"
                                                aria-selected="false">Holiday
                                                Rentals
                                            </button>
                                        </li>
                                        <li class="nav-item " role="presentation">
                                            <button
                                                class="nav-link  text-white w-100 h-100 text-nowrap cursor-pointer position-relative  "
                                                id="car-tab" data-bs-toggle="tab" data-bs-target="#car" type="button"
                                                role="tab" aria-controls="" onclick="swichTab('guest-in-car-tab')"
                                                aria-selected="false">Car</button>
                                        </li>
                                        <li class="nav-item " role="presentation">
                                            <button
                                                class="nav-link  text-white w-100 h-100 text-nowrap cursor-pointer position-relative  "
                                                id="cruise-tab" data-bs-toggle="tab" data-bs-target="#cruise"
                                                type="button" role="tab" aria-controls=""
                                                onclick="swichTab('guest-in-cruise-tab')"
                                                aria-selected="false">Cruise</button>
                                        </li>
                                        <li class="nav-item " role="presentation">
                                            <button
                                                class="nav-link  text-white w-100 h-100 text-nowrap cursor-pointer position-relative  "
                                                id="flights-tab" data-bs-toggle="tab" data-bs-target="#flights"
                                                type="button" role="tab" aria-controls=""
                                                onclick="swichTab('guest-in-flights-tab')"
                                                aria-selected="false">Flights</button>
                                        </li>
                                        <li class="nav-item " role="presentation">
                                            <button
                                                class="nav-link  text-white w-100 h-100 text-nowrap cursor-pointer position-relative  "
                                                id="visa-tab" data-bs-toggle="tab" data-bs-target="#visa" type="button"
                                                role="tab" aria-controls="" onclick="swichTab('guest-in-visa-tab')"
                                                aria-selected="false">VISA</button>
                                        </li>
                                    </ul>
                                    <div class="tab-content mt-lg-0 mt-md-0 mt-sm-0 mt-3 w-100 " id="myTabContent">
                                        <div class="h-100 tab-pane fade active show" id="hotel" role="tabpanel"
                                            aria-labelledby="hotel-tab">
                                            <div class="p-4 card rounded">
                                                <div class="row justify-content-between h-100">
                                                    <div class="col-lg-3 col-md-4 col-sm-6 col-12 h-100 my-auto border-lg-end border-md-end border-sm-bottom"
                                                        h-100="">
                                                        <label for=""
                                                            class=" text-secondary float-start">Location</label>
                                                        <input class="form-control  border-0" type="text" name=""
                                                            placeholder="Where are you going?"
                                                            id="location-in-hotel-tab" data-bs-toggle="dropdown"
                                                            data-bs-auto-close="true" aria-expanded="false">
                                                        <ul class="dropdown-menu col-lg-4 col-md-3 col-sm-6 col-12"
                                                            aria-labelledby="location-in-hotel-tab">
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-hotel-tab','London')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                London
                                                                                <br>
                                                                                Greater London, United Kingdom
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-hotel-tab','New York')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                New York
                                                                                <br>
                                                                                New York State, United States
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-hotel-tab','Paris')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                Paris
                                                                                <br>
                                                                                France
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div
                                                        class="col-lg-3 col-md-4 col-sm-6 col-12 h-100 my-auto border-lg-end border-md-end border-sm-bottom ">
                                                        <label for="" class=" text-secondary float-start">Check in -
                                                            Check
                                                            out
                                                        </label>

                                                        <input type="text" name="datetimes"
                                                            class="form-control  border-0"
                                                            placeholder=" Check in - Check out">


                                                        <script>
                                                            $(function () {
                                                                $('input[name="datetimes"]').daterangepicker({
                                                                    timePicker: true,
                                                                    startDate: moment().startOf('hour'),
                                                                    endDate: moment().startOf('hour').add(32, 'hour'),
                                                                    locale: {
                                                                        format: 'M/DD hh:mm A'
                                                                    }
                                                                });
                                                            });
                                                        </script>
                                                    </div>
                                                    <div class="col-lg-3 col-md-4 col-sm-6 col-12 h-100 my-auto"
                                                        h-100="">
                                                        <label for="" class=" text-secondary float-start">
                                                            No. of travellers
                                                        </label>
                                                        <input class="form-control  border-0" type="text" name=""
                                                            id="guest-in-hotel-tab" data-bs-toggle="dropdown"
                                                            data-bs-auto-close="false" aria-expanded="false">
                                                        <ul class="dropdown-menu col-lg-4 col-md-3 col-sm-6 col-12"
                                                            aria-labelledby="guest-in-hotel-tab">
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row">
                                                                        <div class="col my-auto">
                                                                            <div class="">
                                                                                Adults
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-end">
                                                                            <div class="btn value-button p-2 "
                                                                                id="decrease"
                                                                                onclick="decreaseValue('11','guest-in-hotel-tab',['11','12','13'])"
                                                                                value="Decrease Value">
                                                                                <i class="fa-solid fa-minus"></i>
                                                                            </div>
                                                                            <input class="form-control  border-0"
                                                                                type="number" id="11" value="0" />
                                                                            <div class="btn value-button p-2 "
                                                                                id="increase"
                                                                                onclick="increaseValue('11','guest-in-hotel-tab',['11','12','13'])"
                                                                                value="Increase Value">
                                                                                <i class="fa-solid fa-plus"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row">
                                                                        <div class="col my-auto">
                                                                            <div class="">
                                                                                Children <br>
                                                                                (Ages 0 - 17)
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-end">
                                                                            <div class="btn value-button p-2 "
                                                                                id="decrease"
                                                                                onclick="decreaseValue('12','guest-in-hotel-tab',['11','12','13'])"
                                                                                value="Decrease Value">
                                                                                <i class="fa-solid fa-minus"></i>
                                                                            </div>
                                                                            <input class="form-control  border-0"
                                                                                type="number" id="12" value="0" />
                                                                            <div class="btn value-button p-2 "
                                                                                id="increase"
                                                                                onclick="increaseValue('12','guest-in-hotel-tab',['11','12','13'])"
                                                                                value="Increase Value">
                                                                                <i class="fa-solid fa-plus"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row">
                                                                        <div class="col my-auto">
                                                                            <div class="">
                                                                                Rooms
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-end">
                                                                            <div class="btn value-button p-2 "
                                                                                id="decrease"
                                                                                onclick="decreaseValue('13','guest-in-hotel-tab',['11','12','13'])"
                                                                                value="Decrease Value">
                                                                                <i class="fa-solid fa-minus"></i>
                                                                            </div>
                                                                            <input class="form-control  border-0"
                                                                                type="number" id="13" value="0" />
                                                                            <div class="btn value-button p-2 "
                                                                                id="increase"
                                                                                onclick="increaseValue('13','guest-in-hotel-tab',['11','12','13'])"
                                                                                value="Increase Value">
                                                                                <i class="fa-solid fa-plus"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div
                                                        class="col-lg-6 col-md-6 col-sm-6 col-12 offset-lg-3 offset-md-3 offset-sm-3 offset-0">
                                                        <button
                                                            class="btn btn-primary rounded w-100 h-100  text-white rounded">
                                                            <i
                                                                class="fa-solid fa-magnifying-glass  text-white me-2"></i>
                                                            Search
                                                        </button>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="w-100 h-100 tab-pane fade aos-init aos-animate" data-aos="fade-up "
                                            id="tour" role="tabpanel" aria-labelledby="tour-tab">
                                            <div class="p-4 card rounded ">
                                                <div class="row justify-content-between h-100">
                                                    <div class="col-lg-3 col-md-4 col-sm-6 col-12 h-100 my-auto"
                                                        h-100="">
                                                        <label for=""
                                                            class=" text-secondary float-start">Location</label>
                                                        <input class="form-control  border-0" type="text" name=""
                                                            placeholder="Where are you going?" id="location-in-tour-tab"
                                                            data-bs-toggle="dropdown" data-bs-auto-close="true"
                                                            aria-expanded="false">
                                                        <ul class="dropdown-menu col-lg-4 col-md-3 col-sm-6 col-12"
                                                            aria-labelledby="location-in-tour-tab">
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-tour-tab','London')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                London
                                                                                <br>
                                                                                Greater London, United Kingdom
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-tour-tab','New York')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                New York
                                                                                <br>
                                                                                New York State, United States
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-tour-tab','Paris')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                Paris
                                                                                <br>
                                                                                France
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-lg-3 col-md-4 col-sm-6 col-12 h-100 my-auto">
                                                        <label for="" class=" text-secondary float-start">Check in -
                                                            Check
                                                            out
                                                        </label>

                                                        <input type="text" name="datetimes"
                                                            class="form-control  border-0" />

                                                        <script>
                                                            $(function () {
                                                                $('input[name="datetimes"]').daterangepicker({
                                                                    timePicker: true,
                                                                    startDate: moment().startOf('hour'),
                                                                    endDate: moment().startOf('hour').add(32, 'hour'),
                                                                    locale: {
                                                                        format: 'M/DD hh:mm A'
                                                                    }
                                                                });
                                                            });
                                                        </script>
                                                    </div>
                                                    <div class="col-md-3  h-100 my-auto" h-100="">
                                                        <label for="" class=" text-secondary float-start">
                                                            No. of travellers
                                                        </label>
                                                        <input class="form-control  border-0" type="text" name=""
                                                            id="guest-in-tour-tab" data-bs-toggle="dropdown"
                                                            data-bs-auto-close="false" aria-expanded="false">
                                                        <ul class="dropdown-menu col-lg-4 col-md-3 col-sm-6 col-12"
                                                            aria-labelledby="guest-in-tour-tab">
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row">
                                                                        <div class="col my-auto">
                                                                            <div class="">
                                                                                Adults
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-end">
                                                                            <div class="btn value-button p-2 "
                                                                                id="decrease"
                                                                                onclick="decreaseValue('21','guest-in-tour-tab',['21','22','23'])"
                                                                                value="Decrease Value">
                                                                                <i class="fa-solid fa-minus"></i>
                                                                            </div>
                                                                            <input class="form-control  border-0"
                                                                                type="number" id="21" value="0" />
                                                                            <div class="btn value-button p-2 "
                                                                                id="increase"
                                                                                onclick="increaseValue('21','guest-in-tour-tab',['21','22','23'])"
                                                                                value="Increase Value">
                                                                                <i class="fa-solid fa-plus"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row">
                                                                        <div class="col my-auto">
                                                                            <div class="">
                                                                                Children <br>
                                                                                (Ages 0 - 17)
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-end">
                                                                            <div class="btn value-button p-2 "
                                                                                id="decrease"
                                                                                onclick="decreaseValue('22','guest-in-tour-tab',['22','22','23'])"
                                                                                value="Decrease Value">
                                                                                <i class="fa-solid fa-minus"></i>
                                                                            </div>
                                                                            <input class="form-control  border-0"
                                                                                type="number" id="22" value="0" />
                                                                            <div class="btn value-button p-2 "
                                                                                id="increase"
                                                                                onclick="increaseValue('22','guest-in-tour-tab',['21','22','23'])"
                                                                                value="Increase Value">
                                                                                <i class="fa-solid fa-plus"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row">
                                                                        <div class="col my-auto">
                                                                            <div class="">
                                                                                Rooms
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-end">
                                                                            <div class="btn value-button p-2 "
                                                                                id="decrease"
                                                                                onclick="decreaseValue('23','guest-in-tour-tab',['21','22','23'])"
                                                                                value="Decrease Value">
                                                                                <i class="fa-solid fa-minus"></i>
                                                                            </div>
                                                                            <input class="form-control  border-0"
                                                                                type="number" id="23" value="0" />
                                                                            <div class="btn value-button p-2 "
                                                                                id="increase"
                                                                                onclick="increaseValue('23','guest-in-tour-tab',['21','22','23'])"
                                                                                value="Increase Value">
                                                                                <i class="fa-solid fa-plus"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div
                                                        class="col-lg-6 col-md-6 col-sm-6 col-12 offset-lg-3 offset-md-3 offset-sm-3 offset-0">
                                                        <button
                                                            class="btn btn-primary rounded w-100 h-100  text-white rounded">
                                                            <i
                                                                class="fa-solid fa-magnifying-glass  text-white me-2"></i>
                                                            Search
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="h-100 tab-pane fade show" id="activity" role="tabpanel"
                                            aria-labelledby="activity-tab">
                                            <div class="p-4 card rounded ">
                                                <div class="row justify-content-between h-100">
                                                    <div class="col-lg-3 col-md-4 col-sm-6 col-12 h-100 my-auto"
                                                        h-100="">
                                                        <label for=""
                                                            class="text-secondary float-start">Location</label>
                                                        <input class="form-control border-0" type="text" name=""
                                                            placeholder="Where are you going?"
                                                            id="location-in-activity-tab" data-bs-toggle="dropdown"
                                                            data-bs-auto-close="true" aria-expanded="false">
                                                        <ul class="dropdown-menu col-lg-4 col-md-3 col-sm-6 col-12"
                                                            aria-labelledby="location-in-activity-tab">
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-activity-tab','London')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                London
                                                                                <br>
                                                                                Greater London, United Kingdom
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-activity-tab','New York')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                New York
                                                                                <br>
                                                                                New York State, United States
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-activity-tab','Paris')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                Paris
                                                                                <br>
                                                                                France
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-lg-3 col-md-4 col-sm-6 col-12 h-100 my-auto">
                                                        <label for="" class="text-secondary float-start">Check in -
                                                            Check
                                                            out
                                                        </label>

                                                        <input type="text" name="datetimes"
                                                            class="form-control border-0" />

                                                        <script>
                                                            $(function () {
                                                                $('input[name="datetimes"]').daterangepicker({
                                                                    timePicker: true,
                                                                    startDate: moment().startOf('hour'),
                                                                    endDate: moment().startOf('hour').add(32, 'hour'),
                                                                    locale: {
                                                                        format: 'M/DD hh:mm A'
                                                                    }
                                                                });
                                                            });
                                                        </script>
                                                    </div>
                                                    <div class="col-md-3   h-100 my-auto" h-100="">
                                                        <label for="" class="text-secondary float-start">
                                                            No. of travellers
                                                        </label>
                                                        <input class="form-control border-0" type="text" name=""
                                                            id="guest-in-activity-tab" data-bs-toggle="dropdown"
                                                            data-bs-auto-close="false" aria-expanded="false">
                                                        <ul class="dropdown-menu col-lg-4 col-md-3 col-sm-6 col-12"
                                                            aria-labelledby="guest-in-activity-tab">
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row">
                                                                        <div class="col my-auto">
                                                                            <div class="">
                                                                                Adults
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-end">
                                                                            <div class="btn value-button p-2 "
                                                                                id="decrease"
                                                                                onclick="decreaseValue('31','guest-in-activity-tab',['31','32','33'])"
                                                                                value="Decrease Value">
                                                                                <i class="fa-solid fa-minus"></i>
                                                                            </div>
                                                                            <input class="form-control border-0"
                                                                                type="number" id="31" value="0" />
                                                                            <div class="btn value-button p-2 "
                                                                                id="increase"
                                                                                onclick="increaseValue('31','guest-in-activity-tab',['31','32','33'])"
                                                                                value="Increase Value">
                                                                                <i class="fa-solid fa-plus"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row">
                                                                        <div class="col my-auto">
                                                                            <div class="">
                                                                                Children <br>
                                                                                (Ages 0 - 17)
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-end">
                                                                            <div class="btn value-button p-2 "
                                                                                id="decrease"
                                                                                onclick="decreaseValue('32','guest-in-activity-tab',['31','32','33'])"
                                                                                value="Decrease Value">
                                                                                <i class="fa-solid fa-minus"></i>
                                                                            </div>
                                                                            <input class="form-control border-0"
                                                                                type="number" id="32" value="0" />
                                                                            <div class="btn value-button p-2 "
                                                                                id="increase"
                                                                                onclick="increaseValue('32','guest-in-activity-tab',['31','32','33'])"
                                                                                value="Increase Value">
                                                                                <i class="fa-solid fa-plus"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row">
                                                                        <div class="col my-auto">
                                                                            <div class="">
                                                                                Rooms
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-end">
                                                                            <div class="btn value-button p-2 "
                                                                                id="decrease"
                                                                                onclick="decreaseValue('33','guest-in-activity-tab',['31','32','33'])"
                                                                                value="Decrease Value">
                                                                                <i class="fa-solid fa-minus"></i>
                                                                            </div>
                                                                            <input class="form-control border-0"
                                                                                type="number" id="33" value="0" />
                                                                            <div class="btn value-button p-2 "
                                                                                id="increase"
                                                                                onclick="increaseValue('33','guest-in-activity-tab',['31','32','33'])"
                                                                                value="Increase Value">
                                                                                <i class="fa-solid fa-plus"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div
                                                        class="col-lg-6 col-md-6 col-sm-6 col-12 offset-lg-3 offset-md-3 offset-sm-3 offset-0">
                                                        <button
                                                            class="btn btn-primary rounded w-100 h-100 text-white rounded">
                                                            <i
                                                                class="fa-solid fa-magnifying-glass  text-white me-2"></i>
                                                            Search
                                                        </button>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="h-100 tab-pane fade show aos-init aos-animate" data-aos="fade-up "
                                            id="holiday-rentals" role="tabpanel" aria-labelledby="holiday-rentals-tab">
                                            <div class="p-4 card rounded ">
                                                <div class="row justify-content-between h-100">
                                                    <div class="col-lg-3 col-md-4 col-sm-6 col-12 h-100 my-auto"
                                                        h-100="">
                                                        <label for=""
                                                            class="text-secondary float-start">Location</label>
                                                        <input class="form-control border-0" type="text" name=""
                                                            placeholder="Where are you going?"
                                                            id="location-in-holidayrentals-tab"
                                                            data-bs-toggle="dropdown" data-bs-auto-close="true"
                                                            aria-expanded="false">
                                                        <ul class="dropdown-menu col-lg-4 col-md-3 col-sm-6 col-12"
                                                            aria-labelledby="location-in-holidayrentals-tab">
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-holidayrentals-tab','London')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                London
                                                                                <br>
                                                                                Greater London, United Kingdom
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-holidayrentals-tab','New York')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                New York
                                                                                <br>
                                                                                New York State, United States
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-holidayrentals-tab','Paris')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                Paris
                                                                                <br>
                                                                                France
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-lg-3 col-md-4 col-sm-6 col-12 h-100 my-auto">
                                                        <label for="" class="text-secondary float-start">Check in -
                                                            Check
                                                            out
                                                        </label>

                                                        <input type="text" name="datetimes"
                                                            class="form-control border-0" />

                                                        <script>
                                                            $(function () {
                                                                $('input[name="datetimes"]').daterangepicker({
                                                                    timePicker: true,
                                                                    startDate: moment().startOf('hour'),
                                                                    endDate: moment().startOf('hour').add(32, 'hour'),
                                                                    locale: {
                                                                        format: 'M/DD hh:mm A'
                                                                    }
                                                                });
                                                            });
                                                        </script>
                                                    </div>
                                                    <div class="col-md-3  h-100 my-auto" h-100="">
                                                        <label for="" class="text-secondary float-start">
                                                            No. of travellers
                                                        </label>
                                                        <input class="form-control border-0" type="text" name=""
                                                            id="guest-in-holidayrentals-tab" data-bs-toggle="dropdown"
                                                            data-bs-auto-close="false" aria-expanded="false">
                                                        <ul class="dropdown-menu col-lg-4 col-md-3 col-sm-6 col-12"
                                                            aria-labelledby="guest-in-holidayrentals-tab">
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row">
                                                                        <div class="col my-auto">
                                                                            <div class="">
                                                                                Adults
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-end">
                                                                            <div class="btn value-button p-2 "
                                                                                id="decrease"
                                                                                onclick="decreaseValue('41','guest-in-holidayrentals-tab',['41','42','43'])"
                                                                                value="Decrease Value">
                                                                                <i class="fa-solid fa-minus"></i>
                                                                            </div>
                                                                            <input class="form-control border-0"
                                                                                type="number" id="41" value="0" />
                                                                            <div class="btn value-button p-2 "
                                                                                id="increase"
                                                                                onclick="increaseValue('41','guest-in-holidayrentals-tab',['41','42','43'])"
                                                                                value="Increase Value">
                                                                                <i class="fa-solid fa-plus"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row">
                                                                        <div class="col my-auto">
                                                                            <div class="">
                                                                                Children <br>
                                                                                (Ages 0 - 17)
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-end">
                                                                            <div class="btn value-button p-2 "
                                                                                id="decrease"
                                                                                onclick="decreaseValue('42','guest-in-holidayrentals-tab',['41','42','43'])"
                                                                                value="Decrease Value">
                                                                                <i class="fa-solid fa-minus"></i>
                                                                            </div>
                                                                            <input class="form-control border-0"
                                                                                type="number" id="42" value="0" />
                                                                            <div class="btn value-button p-2 "
                                                                                id="increase"
                                                                                onclick="increaseValue('42','guest-in-holidayrentals-tab',['41','42','43'])"
                                                                                value="Increase Value">
                                                                                <i class="fa-solid fa-plus"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row">
                                                                        <div class="col my-auto">
                                                                            <div class="">
                                                                                Rooms
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-end">
                                                                            <div class="btn value-button p-2 "
                                                                                id="decrease"
                                                                                onclick="decreaseValue('43','guest-in-holidayrentals-tab',['41','42','43'])"
                                                                                value="Decrease Value">
                                                                                <i class="fa-solid fa-minus"></i>
                                                                            </div>
                                                                            <input class="form-control border-0"
                                                                                type="number" id="43" value="0" />
                                                                            <div class="btn value-button p-2 "
                                                                                id="increase"
                                                                                onclick="increaseValue('43','guest-in-holidayrentals-tab',['41','42','43'])"
                                                                                value="Increase Value">
                                                                                <i class="fa-solid fa-plus"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div
                                                        class="col-lg-6 col-md-6 col-sm-6 col-12 offset-lg-3 offset-md-3 offset-sm-3 offset-0">
                                                        <button
                                                            class="btn btn-primary rounded w-100 h-100 text-white rounded">
                                                            <i
                                                                class="fa-solid fa-magnifying-glass  text-white me-2"></i>
                                                            Search
                                                        </button>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="h-100 tab-pane fade show aos-init aos-animate" data-aos="fade-up "
                                            id="car" role="tabpanel" aria-labelledby="car-tab">
                                            <div class="p-4 card rounded ">
                                                <div class="row justify-content-between h-100">
                                                    <div class="col-lg-3 col-md-4 col-sm-6 col-12 h-100 my-auto"
                                                        h-100="">
                                                        <label for=""
                                                            class="text-secondary float-start">Location</label>
                                                        <input class="form-control border-0" type="text" name=""
                                                            placeholder="Where are you going?" id="location-in-car-tab"
                                                            data-bs-toggle="dropdown" data-bs-auto-close="true"
                                                            aria-expanded="false">
                                                        <ul class="dropdown-menu col-lg-4 col-md-3 col-sm-6 col-12"
                                                            aria-labelledby="location-in-car-tab">
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-car-tab','London')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                London
                                                                                <br>
                                                                                Greater London, United Kingdom
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-car-tab','New York')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                New York
                                                                                <br>
                                                                                New York State, United States
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-car-tab','Paris')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                Paris
                                                                                <br>
                                                                                France
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-lg-3 col-md-4 col-sm-6 col-12 h-100 my-auto">
                                                        <label for="" class="text-secondary float-start">Check in -
                                                            Check
                                                            out
                                                        </label>

                                                        <input type="text" name="datetimes"
                                                            class="form-control border-0" />

                                                        <script>
                                                            $(function () {
                                                                $('input[name="datetimes"]').daterangepicker({
                                                                    timePicker: true,
                                                                    startDate: moment().startOf('hour'),
                                                                    endDate: moment().startOf('hour').add(32, 'hour'),
                                                                    locale: {
                                                                        format: 'M/DD hh:mm A'
                                                                    }
                                                                });
                                                            });
                                                        </script>
                                                    </div>
                                                    <div class="col-md-3  h-100 my-auto" h-100="">
                                                        <label for="" class="text-secondary float-start">
                                                            No. of travellers
                                                        </label>
                                                        <input class="form-control border-0" type="text" name=""
                                                            id="guest-in-car-tab" data-bs-toggle="dropdown"
                                                            data-bs-auto-close="false" aria-expanded="false">
                                                        <ul class="dropdown-menu col-lg-4 col-md-3 col-sm-6 col-12"
                                                            aria-labelledby="guest-in-car-tab">
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row">
                                                                        <div class="col my-auto">
                                                                            <div class="">
                                                                                Adults
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-end">
                                                                            <div class="btn value-button p-2 "
                                                                                id="decrease"
                                                                                onclick="decreaseValue('51','guest-in-car-tab',['51','52','53'])"
                                                                                value="Decrease Value">
                                                                                <i class="fa-solid fa-minus"></i>
                                                                            </div>
                                                                            <input class="form-control border-0"
                                                                                type="number" id="51" value="0" />
                                                                            <div class="btn value-button p-2 "
                                                                                id="increase"
                                                                                onclick="increaseValue('51','guest-in-car-tab',['51','52','53'])"
                                                                                value="Increase Value">
                                                                                <i class="fa-solid fa-plus"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row">
                                                                        <div class="col my-auto">
                                                                            <div class="">
                                                                                Children <br>
                                                                                (Ages 0 - 17)
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-end">
                                                                            <div class="btn value-button p-2 "
                                                                                id="decrease"
                                                                                onclick="decreaseValue('52','guest-in-car-tab',['51','52','53'])"
                                                                                value="Decrease Value">
                                                                                <i class="fa-solid fa-minus"></i>
                                                                            </div>
                                                                            <input class="form-control border-0"
                                                                                type="number" id="52" value="0" />
                                                                            <div class="btn value-button p-2 "
                                                                                id="increase"
                                                                                onclick="increaseValue('52','guest-in-car-tab',['51','52','53'])"
                                                                                value="Increase Value">
                                                                                <i class="fa-solid fa-plus"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row">
                                                                        <div class="col my-auto">
                                                                            <div class="">
                                                                                Rooms
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-end">
                                                                            <div class="btn value-button p-2 "
                                                                                id="decrease"
                                                                                onclick="decreaseValue('53','guest-in-car-tab',['51','52','53'])"
                                                                                value="Decrease Value">
                                                                                <i class="fa-solid fa-minus"></i>
                                                                            </div>
                                                                            <input class="form-control border-0"
                                                                                type="number" id="53" value="0" />
                                                                            <div class="btn value-button p-2 "
                                                                                id="increase"
                                                                                onclick="increaseValue('53','guest-in-car-tab',['51','52','53'])"
                                                                                value="Increase Value">
                                                                                <i class="fa-solid fa-plus"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div
                                                        class="col-lg-6 col-md-6 col-sm-6 col-12 offset-lg-3 offset-md-3 offset-sm-3 offset-0">
                                                        <button
                                                            class="btn btn-primary rounded w-100 h-100 text-white rounded">
                                                            <i
                                                                class="fa-solid fa-magnifying-glass  text-white me-2"></i>
                                                            Search
                                                        </button>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="h-100 tab-pane fade show aos-init aos-animate" data-aos="fade-up "
                                            id="cruise" role="tabpanel" aria-labelledby="cruise-tab">
                                            <div class="p-4 card rounded ">
                                                <div class="row justify-content-between h-100">
                                                    <div class="col-lg-3 col-md-4 col-sm-6 col-12 h-100 my-auto"
                                                        h-100="">
                                                        <label for=""
                                                            class="text-secondary float-start">Location</label>
                                                        <input class="form-control border-0" type="text" name=""
                                                            placeholder="Where are you going?"
                                                            id="location-in-cruise-tab" data-bs-toggle="dropdown"
                                                            data-bs-auto-close="true" aria-expanded="false">
                                                        <ul class="dropdown-menu col-lg-4 col-md-3 col-sm-6 col-12"
                                                            aria-labelledby="location-in-cruise-tab">
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-cruise-tab','London')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                London
                                                                                <br>
                                                                                Greater London, United Kingdom
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-cruise-tab','New York')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                New York
                                                                                <br>
                                                                                New York State, United States
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-cruise-tab','Paris')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                Paris
                                                                                <br>
                                                                                France
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-lg-3 col-md-4 col-sm-6 col-12 h-100 my-auto">
                                                        <label for="" class="text-secondary float-start">Check in -
                                                            Check
                                                            out
                                                        </label>

                                                        <input type="text" name="datetimes"
                                                            class="form-control border-0" />

                                                        <script>
                                                            $(function () {
                                                                $('input[name="datetimes"]').daterangepicker({
                                                                    timePicker: true,
                                                                    startDate: moment().startOf('hour'),
                                                                    endDate: moment().startOf('hour').add(32, 'hour'),
                                                                    locale: {
                                                                        format: 'M/DD hh:mm A'
                                                                    }
                                                                });
                                                            });
                                                        </script>
                                                    </div>
                                                    <div class="col-md-3 h-100 my-auto" h-100="">
                                                        <label for="" class="text-secondary float-start">
                                                            No. of travellers
                                                        </label>
                                                        <input class="form-control border-0" type="text" name=""
                                                            id="guest-in-cruise-tab" data-bs-toggle="dropdown"
                                                            data-bs-auto-close="false" aria-expanded="false">
                                                        <ul class="dropdown-menu col-lg-4 col-md-3 col-sm-6 col-12"
                                                            aria-labelledby="guest-in-cruise-tab">
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row">
                                                                        <div class="col my-auto">
                                                                            <div class="">
                                                                                Adults
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-end">
                                                                            <div class="btn value-button p-2 "
                                                                                id="decrease"
                                                                                onclick="decreaseValue('61','guest-in-cruise-tab',['61','62','63'])"
                                                                                value="Decrease Value">
                                                                                <i class="fa-solid fa-minus"></i>
                                                                            </div>
                                                                            <input class="form-control border-0"
                                                                                type="number" id="61" value="0" />
                                                                            <div class="btn value-button p-2 "
                                                                                id="increase"
                                                                                onclick="increaseValue('61','guest-in-cruise-tab',['61','62','63'])"
                                                                                value="Increase Value">
                                                                                <i class="fa-solid fa-plus"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row">
                                                                        <div class="col my-auto">
                                                                            <div class="">
                                                                                Children <br>
                                                                                (Ages 0 - 17)
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-end">
                                                                            <div class="btn value-button p-2 "
                                                                                id="decrease"
                                                                                onclick="decreaseValue('62','guest-in-cruise-tab',['61','62','63'])"
                                                                                value="Decrease Value">
                                                                                <i class="fa-solid fa-minus"></i>
                                                                            </div>
                                                                            <input class="form-control border-0"
                                                                                type="number" id="62" value="0" />
                                                                            <div class="btn value-button p-2 "
                                                                                id="increase"
                                                                                onclick="increaseValue('62','guest-in-cruise-tab',['61','62','63'])"
                                                                                value="Increase Value">
                                                                                <i class="fa-solid fa-plus"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row">
                                                                        <div class="col my-auto">
                                                                            <div class="">
                                                                                Rooms
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-end">
                                                                            <div class="btn value-button p-2 "
                                                                                id="decrease"
                                                                                onclick="decreaseValue('63','guest-in-cruise-tab',['61','62','63'])"
                                                                                value="Decrease Value">
                                                                                <i class="fa-solid fa-minus"></i>
                                                                            </div>
                                                                            <input class="form-control border-0"
                                                                                type="number" id="63" value="0" />
                                                                            <div class="btn value-button p-2 "
                                                                                id="increase"
                                                                                onclick="increaseValue('63','guest-in-cruise-tab',['61','62','63'])"
                                                                                value="Increase Value">
                                                                                <i class="fa-solid fa-plus"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div
                                                        class="col-lg-6 col-md-6 col-sm-6 col-12 offset-lg-3 offset-md-3 offset-sm-3 offset-0">
                                                        <button
                                                            class="btn btn-primary rounded w-100 h-100 text-white rounded">
                                                            <i
                                                                class="fa-solid fa-magnifying-glass  text-white me-2"></i>
                                                            Search
                                                        </button>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="h-100 tab-pane fade show aos-init aos-animate" data-aos="fade-up "
                                            id="flights" role="tabpanel" aria-labelledby="flights-tab">
                                            <div class="p-4 card rounded ">
                                                <div class="row justify-content-between h-100">
                                                    <div class="col-lg-3 col-md-4 col-sm-6 col-12 h-100 my-auto"
                                                        h-100="">
                                                        <label for=""
                                                            class="text-secondary float-start">Location</label>
                                                        <input class="form-control border-0" type="text" name=""
                                                            placeholder="Where are you going?"
                                                            id="location-in-flights-tab" data-bs-toggle="dropdown"
                                                            data-bs-auto-close="true" aria-expanded="false">
                                                        <ul class="dropdown-menu col-lg-4 col-md-3 col-sm-6 col-12"
                                                            aria-labelledby="location-in-flights-tab">
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-flights-tab','London')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                London
                                                                                <br>
                                                                                Greater London, United Kingdom
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-flights-tab','New York')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                New York
                                                                                <br>
                                                                                New York State, United States
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-flights-tab','Paris')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                Paris
                                                                                <br>
                                                                                France
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-lg-3 col-md-4 col-sm-6 col-12 h-100 my-auto">
                                                        <label for="" class="text-secondary float-start">Check in -
                                                            Check
                                                            out
                                                        </label>

                                                        <input type="text" name="datetimes"
                                                            class="form-control border-0" />

                                                        <script>
                                                            $(function () {
                                                                $('input[name="datetimes"]').daterangepicker({
                                                                    timePicker: true,
                                                                    startDate: moment().startOf('hour'),
                                                                    endDate: moment().startOf('hour').add(32, 'hour'),
                                                                    locale: {
                                                                        format: 'M/DD hh:mm A'
                                                                    }
                                                                });
                                                            });
                                                        </script>
                                                    </div>
                                                    <div class="col-md-3   h-100 my-auto" h-100="">
                                                        <label for="" class="text-secondary float-start">
                                                            No. of travellers
                                                        </label>
                                                        <input class="form-control border-0" type="text" name=""
                                                            id="guest-in-flights-tab" data-bs-toggle="dropdown"
                                                            data-bs-auto-close="false" aria-expanded="false">
                                                        <ul class="dropdown-menu col-lg-4 col-md-3 col-sm-6 col-12"
                                                            aria-labelledby="guest-in-flights-tab">
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row">
                                                                        <div class="col my-auto">
                                                                            <div class="">
                                                                                Adults
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-end">
                                                                            <div class="btn value-button p-2 "
                                                                                id="decrease"
                                                                                onclick="decreaseValue('71','guest-in-flights-tab',['71','72','73'])"
                                                                                value="Decrease Value">
                                                                                <i class="fa-solid fa-minus"></i>
                                                                            </div>
                                                                            <input class="form-control border-0"
                                                                                type="number" id="71" value="0" />
                                                                            <div class="btn value-button p-2 "
                                                                                id="increase"
                                                                                onclick="increaseValue('71','guest-in-flights-tab',['71','72','73'])"
                                                                                value="Increase Value">
                                                                                <i class="fa-solid fa-plus"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row">
                                                                        <div class="col my-auto">
                                                                            <div class="">
                                                                                Children <br>
                                                                                (Ages 0 - 17)
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-end">
                                                                            <div class="btn value-button p-2 "
                                                                                id="decrease"
                                                                                onclick="decreaseValue('72','guest-in-flights-tab',['71','72','73'])"
                                                                                value="Decrease Value">
                                                                                <i class="fa-solid fa-minus"></i>
                                                                            </div>
                                                                            <input class="form-control border-0"
                                                                                type="number" id="72" value="0" />
                                                                            <div class="btn value-button p-2 "
                                                                                id="increase"
                                                                                onclick="increaseValue('72','guest-in-flights-tab',['71','72','73'])"
                                                                                value="Increase Value">
                                                                                <i class="fa-solid fa-plus"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row">
                                                                        <div class="col my-auto">
                                                                            <div class="">
                                                                                Rooms
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-end">
                                                                            <div class="btn value-button p-2 "
                                                                                id="decrease"
                                                                                onclick="decreaseValue('73','guest-in-flights-tab',['71','72','73'])"
                                                                                value="Decrease Value">
                                                                                <i class="fa-solid fa-minus"></i>
                                                                            </div>
                                                                            <input class="form-control border-0"
                                                                                type="number" id="73" value="0" />
                                                                            <div class="btn value-button p-2 "
                                                                                id="increase"
                                                                                onclick="increaseValue('73','guest-in-flights-tab',['71','72','73'])"
                                                                                value="Increase Value">
                                                                                <i class="fa-solid fa-plus"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div
                                                        class="col-lg-6 col-md-6 col-sm-6 col-12 offset-lg-3 offset-md-3 offset-sm-3 offset-0">
                                                        <button
                                                            class="btn btn-primary rounded w-100 h-100 text-white rounded">
                                                            <i
                                                                class="fa-solid fa-magnifying-glass  text-white me-2"></i>
                                                            Search
                                                        </button>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="h-100 tab-pane fade show aos-init aos-animate" data-aos="fade-up "
                                            id="visa" role="tabpanel" aria-labelledby="visa-tab">
                                            <div class="p-4 card rounded ">
                                                <div class="row justify-content-between h-100">
                                                    <div class="col-lg-3 col-md-4 col-sm-6 col-12 h-100 my-auto"
                                                        h-100="">
                                                        <label for="" class="text-secondary float-start">From
                                                            Country</label>
                                                        <input class="form-control border-0" type="text" name=""
                                                            placeholder="Where are you going?"
                                                            id="location-in-visa-tab-from-country"
                                                            data-bs-toggle="dropdown" data-bs-auto-close="true"
                                                            aria-expanded="false">
                                                        <ul class="dropdown-menu col-lg-4 col-md-3 col-sm-6 col-12"
                                                            aria-labelledby="location-in-visa-tab-from-country">
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-visa-tab-from-country','London')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                London
                                                                                <br>
                                                                                Greater London, United Kingdom
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-visa-tab-from-country','New York')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                New York
                                                                                <br>
                                                                                New York State, United States
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-visa-tab-from-country','Paris')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                Paris
                                                                                <br>
                                                                                France
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-lg-3 col-md-4 col-sm-6 col-12 h-100 my-auto"
                                                        h-100="">
                                                        <label for="" class="text-secondary float-start">To
                                                            Country</label>
                                                        <input class="form-control border-0" type="text" name=""
                                                            placeholder="Where are you going?"
                                                            id="location-in-visa-tab-to-country"
                                                            data-bs-toggle="dropdown" data-bs-auto-close="true"
                                                            aria-expanded="false">
                                                        <ul class="dropdown-menu col-lg-4 col-md-3 col-sm-6 col-12"
                                                            aria-labelledby="location-in-visa-tab-to-country">
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-visa-tab-to-country','London')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                London
                                                                                <br>
                                                                                Greater London, United Kingdom
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-visa-tab-to-country','New York')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                New York
                                                                                <br>
                                                                                New York State, United States
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row"
                                                                        onclick="chooseLocation('location-in-visa-tab-to-country','Paris')">
                                                                        <div class="col-auto my-auto">
                                                                            <div class="">
                                                                                <i class="fa-solid fa-location-dot"></i>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-start">
                                                                            <div class="">
                                                                                Paris
                                                                                <br>
                                                                                France
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-3 h-100 my-auto" h-100="">
                                                        <label for="" class="text-secondary float-start">
                                                            No. of travellers
                                                        </label>
                                                        <input class="form-control border-0" type="text" name=""
                                                            id="guest-in-visa-tab" data-bs-toggle="dropdown"
                                                            data-bs-auto-close="false" aria-expanded="false">
                                                        <ul class="dropdown-menu col-lg-4 col-md-3 col-sm-6 col-12"
                                                            aria-labelledby="guest-in-visa-tab">
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row">
                                                                        <div class="col my-auto">
                                                                            <div class="">
                                                                                Adults
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-end">
                                                                            <div class="btn value-button p-2 "
                                                                                id="decrease"
                                                                                onclick="decreaseValue('81','guest-in-visa-tab',['81','82','83'])"
                                                                                value="Decrease Value">
                                                                                <i class="fa-solid fa-minus"></i>
                                                                            </div>
                                                                            <input class="form-control border-0"
                                                                                type="number" id="81" value="0" />
                                                                            <div class="btn value-button p-2 "
                                                                                id="increase"
                                                                                onclick="increaseValue('81','guest-in-visa-tab',['81','82','83'])"
                                                                                value="Increase Value">
                                                                                <i class="fa-solid fa-plus"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row">
                                                                        <div class="col my-auto">
                                                                            <div class="">
                                                                                Children <br>
                                                                                (Ages 0 - 17)
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-end">
                                                                            <div class="btn value-button p-2 "
                                                                                id="decrease"
                                                                                onclick="decreaseValue('82','guest-in-visa-tab',['81','82','83'])"
                                                                                value="Decrease Value">
                                                                                <i class="fa-solid fa-minus"></i>
                                                                            </div>
                                                                            <input class="form-control border-0"
                                                                                type="number" id="82" value="0" />
                                                                            <div class="btn value-button p-2 "
                                                                                id="increase"
                                                                                onclick="increaseValue('82','guest-in-visa-tab',['81','82','83'])"
                                                                                value="Increase Value">
                                                                                <i class="fa-solid fa-plus"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                            <li class="border-bottom border-2 border-secondary">
                                                                <a class="dropdown-item" href="#">
                                                                    <div class="row">
                                                                        <div class="col my-auto">
                                                                            <div class="">
                                                                                Rooms
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            class="col  my-auto d-flex justify-content-end">
                                                                            <div class="btn value-button p-2 "
                                                                                id="decrease"
                                                                                onclick="decreaseValue('83','guest-in-visa-tab',['81','82','83'])"
                                                                                value="Decrease Value">
                                                                                <i class="fa-solid fa-minus"></i>
                                                                            </div>
                                                                            <input class="form-control border-0"
                                                                                type="number" id="83" value="0" />
                                                                            <div class="btn value-button p-2 "
                                                                                id="increase"
                                                                                onclick="increaseValue('83','guest-in-visa-tab',['81','82','83'])"
                                                                                value="Increase Value">
                                                                                <i class="fa-solid fa-plus"></i>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                    <div
                                                        class="col-lg-6 col-md-6 col-sm-6 col-12 offset-lg-3 offset-md-3 offset-sm-3 offset-0">
                                                        <button
                                                            class="btn btn-primary rounded w-100 h-100 text-white rounded">
                                                            <i
                                                                class="fa-solid fa-magnifying-glass  text-white me-2"></i>
                                                            Search
                                                        </button>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <?php if(!empty($countries)){ ?>
    <section class="destination my-4">

        <div class="container">
            <div class="destination-header d-flex align-items-center justify-content-between">
                <div>
                    <h3 class="fw-bold text-dark">Popular Destinations</h3>
                    <p>These popular destinations have a lot to offer</p>
                </div>
                <div>
                    <button class="viewalldestination">View All Destinations <i
                            class="fa-solid fa-square-arrow-up-right bg-light"></i></button>
                </div>

            </div>
            <div id="popular-destination" class="carousel slide" data-bs-touch="false">
                <div class="carousel-inner destinationcarouselinner">
                   <?php  foreach ($countries as $key => $value) { ?>	
                    <div class="carousel-item active destinationcarouselitem"><a href="<?php echo base_url().$franhisurl.$value->country_slug."-toursit-guide" ?>">
                        <div class="card">
                            <div class="cardimg">
                                <img src="<?= base_url().$value->country_image?>" class="card-img-top" alt="...">
                                
                            </div>
                            <div class="cardtexttop textcard">
                                <p class="text-center text-white fs-0.4">14 Hotel - 22 Cars 18 Tours - 95 Activity </p>
                            </div>
                            <div class="cardtextbottom">
                                <h3 class="text-center text-white"><?=$value->name?></h3>
                                <div class="text-center textcard">
                                    <button class="text-center cardbtn">Discover</button>
                                </div>

                            </div>

                        </div>
                    </a></div>
                   <?php  } ?>
                </div>
                <button class="carousel-control-prev destinationprev" type="button"
                    data-bs-target="#popular-destination" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon text-secondary " aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next  destinationnext" type="button"
                    data-bs-target="#popular-destination" data-bs-slide="next">
                    <span class="carousel-control-next-icon text-secondary " aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
        </div>
    </section>
	<?php } ?>
    <section class="layout-pt-md layout-pb-md mt-5">
        <div data-anim="slide-up delay-1" class="container is-in-view">
            <div class="row y-gap-10 justify-content-between items-end">
                <div class="col-auto">
                    <div class="sectionTitle -md">
                        <h2 class="sectionTitle__title">Recommended</h2>
                        <p class=" sectionTitle__text mt-2 sm:mt-0">Interdum et malesuada fames ac ante ipsum</p>
                    </div>
                </div>

                <div class="col-sm-auto">

                    <div class="dropdown">
                        <!-- <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            Dropdown button
                        </button> -->
                        <select class="form-select" aria-label="Default select example">
                            <option value="Hotel"> Hotel</option>
                            <option value="Tour"> Tour</option>
                            <option value="Activity"> Activity</option>
                            <option value="Holiday Rentals"> Holiday Rentals</option>
                            <option value="Car"> Car</option>
                            <option value="Cruise"> Cruise</option>
                            <option value="Flights"> Flights</option>
                            <option value="VISA"> VISA</option>
                        </select>
                    </div>




                </div>
            </div>

            <section id="recommended">
                <div id="recommended-row" class="row  flex-nowrap mx-5 overflow-hidden">
                    <div class="col-12 col-sm-12 col-md-6 col-lg-4 col-xl-3">
                        <div class="card">
                            <div class="card-img">
                                <img src="./assets/img/recomended3.png.png" class="img-fluid">
                            </div>
                            <div class="card-img-overlay ps-0 pe-2 ">
                                <div class=" d-flex align-items-center justify-content-between">
                                    <div class="imgtext rounded-end  " style="background-color: #3554d1;;">
                                        <p class="text-white mb-0 p-2">BEST SELLER</p>
                                    </div>
                                    <div class="imgicon"><i class="fa-regular fa-heart bg-white p-2 rounded-circle"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="recommendedcardtext position-relative mt-2">
                            <h5 class="fw-bold text-dark">Staycity Aparthotels Deptford Bridge Station</h5>
                            <p class="city">Ciutat Vella, Barcelona </p>
                            <div class="d-flex align-items-center mt-2">
                                <div class="text-black "
                                    style="background-color: #3554d1;padding:5px 10px;border-radius: 6px;">
                                    <p class="mb-0 text-white">4.8</p>
                                </div>

                                <div class="text-dark ms-2">
                                    <p style="font-size:14px ;" class="text-dark mb-0 p-2">Exceptional</p>
                                </div>
                                <div class=" ms-2">
                                    <p style="font-size:14px ;" class="mb-0">1,014 reviews</p>
                                </div>
                            </div>
                            <div class="d-flex align-items-center mt-2">
                                <h6 class="text-dark mb-0 p-2">Starting from</h6> <strong
                                    style="color:#3554d1 !important;margin-left:10px">US$72</strong>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-12 col-md-6 col-lg-4 col-xl-3">
                        <div class="card">
                            <div class="card-img">
                                <img src="./assets/img/recommended4.png" class="img-fluid">
                            </div>
                            <div class="card-img-overlay ps-0 pe-2 ">
                                <div class=" d-flex align-items-center justify-content-between">
                                    <div class="imgtext rounded-end  " style="background-color: #f8d448;">
                                        <p class="text-dark mb-0 p-2">TOP RATED</p>
                                    </div>
                                    <div class="imgicon"><i class="fa-regular fa-heart bg-white p-2 rounded-circle"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="recommendedcardtext position-relative mt-2">
                            <h5 class="fw-bold text-dark">The Westin New York at Times Square </h5>
                            <p class="city">Manhattan,New York </p>
                            <div class="d-flex align-items-center mt-2">
                                <div class="text-black "
                                    style="background-color: #3554d1;padding:5px 10px;border-radius: 6px;">
                                    <p class="mb-0 text-white">4.8</p>
                                </div>

                                <div class="text-dark ms-2">
                                    <p style="font-size:14px ;" class="text-dark mb-0 p-2">Exceptional</p>
                                </div>
                                <div class=" ms-2">
                                    <p style="font-size:14px ;" class="mb-0">1,014 reviews</p>
                                </div>
                            </div>
                            <div class="d-flex align-items-center mt-2">
                                <h6 class="text-dark mb-0 p-2">Starting from</h6> <strong
                                    style="color:#3554d1 !important;margin-left:10px">US$72</strong>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-12 col-md-6 col-lg-4 col-xl-3">
                        <div class="card">
                            <div class="card-img">
                                <img src="./assets/img/recommended4.png" class="img-fluid">
                            </div>
                            <div class="card-img-overlay ps-0 pe-2 ">
                                <div class=" d-flex align-items-center justify-content-between">
                                    <div class="imgtext rounded-end  " style="background-color: #f8d448;">
                                        <p class="text-dark mb-0 p-2">TOP RATED</p>
                                    </div>
                                    <div class="imgicon"><i class="fa-regular fa-heart bg-white p-2 rounded-circle"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="recommendedcardtext position-relative mt-2">
                            <h5 class="fw-bold text-dark">The Westin New York at Times Square </h5>
                            <p class="city">Manhattan,New York </p>
                            <div class="d-flex align-items-center mt-2">
                                <div class="text-black "
                                    style="background-color: #3554d1;padding:5px 10px;border-radius: 6px;">
                                    <p class="mb-0 text-white">4.8</p>
                                </div>

                                <div class="text-dark ms-2">
                                    <p style="font-size:14px ;" class="text-dark mb-0 p-2">Exceptional</p>
                                </div>
                                <div class=" ms-2">
                                    <p style="font-size:14px ;" class="mb-0">1,014 reviews</p>
                                </div>
                            </div>
                            <div class="d-flex align-items-center mt-2">
                                <h6 class="text-dark mb-0 p-2">Starting from</h6> <strong
                                    style="color:#3554d1 !important;margin-left:10px">US$72</strong>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-12 col-md-6 col-lg-4 col-xl-3">
                        <div class="card">
                            <div class="card-img">
                                <img src="./assets/img/recommended4.png" class="img-fluid">
                            </div>
                            <div class="card-img-overlay ps-0 pe-2 ">
                                <div class=" d-flex align-items-center justify-content-between">
                                    <div class="imgtext rounded-end  " style="background-color: #f8d448;">
                                        <p class="text-dark mb-0 p-2">TOP RATED</p>
                                    </div>
                                    <div class="imgicon"><i class="fa-regular fa-heart bg-white p-2 rounded-circle"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="recommendedcardtext position-relative mt-2">
                            <h5 class="fw-bold text-dark">The Westin New York at Times Square </h5>
                            <p class="city">Manhattan,New York </p>
                            <div class="d-flex align-items-center mt-2">
                                <div class="text-black "
                                    style="background-color: #3554d1;padding:5px 10px;border-radius: 6px;">
                                    <p class="mb-0 text-white">4.8</p>
                                </div>

                                <div class="text-dark ms-2">
                                    <p style="font-size:14px ;" class="text-dark mb-0 p-2">Exceptional</p>
                                </div>
                                <div class=" ms-2">
                                    <p style="font-size:14px ;" class="mb-0">1,014 reviews</p>
                                </div>
                            </div>
                            <div class="d-flex align-items-center mt-2">
                                <h6 class="text-dark mb-0 p-2">Starting from</h6> <strong
                                    style="color:#3554d1 !important;margin-left:10px">US$72</strong>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-12 col-md-6 col-lg-4 col-xl-3">
                        <div class="card">
                            <div class="card-img">
                                <img src="./assets/img/recommended2.png" class="img-fluid">
                            </div>
                            <div class="card-img-overlay ps-0 pe-2 ">
                                <div class=" d-flex align-items-center justify-content-end">
                                    <div class="imgicon rounded-end  "><i
                                            class="fa-regular fa-heart bg-white p-2 rounded-circle"></i></div>
                                </div>
                            </div>
                        </div>
                        <div class="recommendedcardtext position-relative mt-2">
                            <h5 class="fw-bold text-dark">The Montcalm At Brewery London City </h5>
                            <p class="city">Westminster Borough, London</p>
                            <div class="d-flex align-items-center mt-2">
                                <div class="text-black "
                                    style="background-color: #3554d1;padding:5px 10px;border-radius: 6px;">
                                    <p class="mb-0 text-white">4.8</p>
                                </div>

                                <div class="text-dark ms-2">
                                    <p style="font-size:14px ;" class="text-dark mb-0 p-2">Exceptional</p>
                                </div>
                                <div class=" ms-2">
                                    <p style="font-size:14px ;" class="mb-0">1,014 reviews</p>
                                </div>
                            </div>
                            <div class="d-flex align-items-center mt-2">
                                <h6 class="text-dark mb-0 p-2">Starting from</h6> <strong
                                    style="color:#3554d1 !important;margin-left:10px">US$72</strong>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-12 col-md-6 col-lg-4 col-xl-3">
                        <div class="card">
                            <div class="card-img">
                                <img src="./assets/img/recommended1.png" class="img-fluid">
                            </div>
                            <div class="card-img-overlay ps-0 pe-2 ">
                                <div class=" d-flex align-items-center justify-content-between">
                                    <div class="imgtex rounded-end  t bg-dark">
                                        <p class="text-white mb-0 p-2">BREAKFAST INCLUDED</p>
                                    </div>
                                    <div class="imgicon"><i class="fa-regular fa-heart bg-white p-2 rounded-circle"></i>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="recommendedcardtext position-relative mt-2">
                            <h5 class="fw-bold text-dark">DoubleTree by Hilton Hotel New York times Square West
                            </h5>
                            <p class="city">Vaticano Prati, Rome </p>
                            <div class="d-flex align-items-center mt-2">
                                <div class="text-black "
                                    style="background-color: #3554d1;padding:5px 10px;border-radius: 6px;">
                                    <p class="mb-0 text-white">4.8</p>
                                </div>

                                <div class="text-dark ms-2">
                                    <p style="font-size:14px ;" class="text-dark mb-0 p-2">Exceptional</p>
                                </div>
                                <div class=" ms-2">
                                    <p style="font-size:14px ;" class="mb-0">1,014 reviews</p>
                                </div>
                            </div>
                            <div class="d-flex align-items-center mt-2">
                                <h6 class="text-dark mb-0 p-2">Starting from</h6> <strong
                                    style="color:#3554d1 !important;margin-left:10px">US$72</strong>
                            </div>
                        </div>

                    </div>
                    <div class="col-12 col-sm-12 col-md-6 col-lg-4 col-xl-3">
                        <div class="card">
                            <div class="card-img">
                                <img src="./assets/img/recommended4.png" class="img-fluid">
                            </div>
                            <div class="card-img-overlay ps-0 pe-2 ">
                                <div class=" d-flex align-items-center justify-content-between">
                                    <div class="imgtext rounded-end  " style="background-color: #f8d448;">
                                        <p class="text-dark mb-0 p-2">TOP RATED</p>
                                    </div>
                                    <div class="imgicon"><i class="fa-regular fa-heart bg-white p-2 rounded-circle"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="recommendedcardtext position-relative mt-2">
                            <h5 class="fw-bold text-dark">The Westin New York at Times Square </h5>
                            <p class="city">Manhattan,New York </p>
                            <div class="d-flex align-items-center mt-2">
                                <div class="text-black "
                                    style="background-color: #3554d1;padding:5px 10px;border-radius: 6px;">
                                    <p class="mb-0 text-white">4.8</p>
                                </div>

                                <div class="text-dark ms-2">
                                    <p style="font-size:14px ;" class="text-dark mb-0 p-2">Exceptional</p>
                                </div>
                                <div class=" ms-2">
                                    <p style="font-size:14px ;" class="mb-0">1,014 reviews</p>
                                </div>
                            </div>
                            <div class="d-flex align-items-center mt-2">
                                <h6 class="text-dark mb-0 p-2">Starting from</h6> <strong
                                    style="color:#3554d1 !important;margin-left:10px">US$72</strong>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-12 col-md-6 col-lg-4 col-xl-3">
                        <div class="card">
                            <div class="card-img">
                                <img src="./assets/img/recommended4.png" class="img-fluid">
                            </div>
                            <div class="card-img-overlay ps-0 pe-2 ">
                                <div class=" d-flex align-items-center justify-content-between">
                                    <div class="imgtext rounded-end  " style="background-color: #f8d448;">
                                        <p class="text-dark mb-0 p-2">TOP RATED</p>
                                    </div>
                                    <div class="imgicon"><i class="fa-regular fa-heart bg-white p-2 rounded-circle"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="recommendedcardtext position-relative mt-2">
                            <h5 class="fw-bold text-dark">The Westin New York at Times Square </h5>
                            <p class="city">Manhattan,New York </p>
                            <div class="d-flex align-items-center mt-2">
                                <div class="text-black "
                                    style="background-color: #3554d1;padding:5px 10px;border-radius: 6px;">
                                    <p class="mb-0 text-white">4.8</p>
                                </div>

                                <div class="text-dark ms-2">
                                    <p style="font-size:14px ;" class="text-dark mb-0 p-2">Exceptional</p>
                                </div>
                                <div class=" ms-2">
                                    <p style="font-size:14px ;" class="mb-0">1,014 reviews</p>
                                </div>
                            </div>
                            <div class="d-flex align-items-center mt-2">
                                <h6 class="text-dark mb-0 p-2">Starting from</h6> <strong
                                    style="color:#3554d1 !important;margin-left:10px">US$72</strong>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center mt-5">
                    <button class="btn me-2" onclick="buttonLeft()">
                        <i class="fa-solid fa-arrow-left"></i>
                    </button>
                    <ul class="list-group flex-row flex-nowrap overflow-scroll pagination-bullets"
                        id="pagination-bullets-scroll">
                        <li class="list-group-item border-0 px-3">
                            <i class="fa-solid fa-circle fa-2xs bullet-dot "></i>
                        </li>
                        <li class="list-group-item border-0 px-3">
                            <i class="fa-solid fa-circle fa-2xs bullet-dot "></i>
                        </li>
                        <li class="list-group-item border-0 px-3">
                            <i class="fa-solid fa-circle fa-2xs bullet-dot "></i>
                        </li>
                        <li class="list-group-item border-0 px-3">
                            <i class="fa-solid fa-circle fa-2xs bullet-dot "></i>
                        </li>
                        <li class="list-group-item border-0 px-3">
                            <i class="fa-solid fa-circle fa-2xs bullet-dot "></i>
                        </li>
                        <li class="list-group-item border-0 px-3">
                            <i class="fa-solid fa-circle fa-2xs bullet-dot "></i>
                        </li>
                        <li class="list-group-item border-0 px-3">
                            <i class="fa-solid fa-circle fa-2xs bullet-dot "></i>
                        </li>
                        <li class="list-group-item border-0 px-3">
                            <i class="fa-solid fa-circle fa-2xs bullet-dot "></i>
                        </li>
                    </ul>
                    <button class="btn" onclick="buttonRight()">
                        <i class="fa-solid fa-arrow-right"></i>
                    </button>
                </div>
            </section>
        </div>
    </section>


    <section id="about" class="about my-5">
        <div class="container">
            <div class="row">
                <div class="col-xl-6 col-lg-7" data-aos="fade-right">
                    <img src="https://cdn.pixabay.com/photo/2019/12/10/10/53/architecture-4685608__340.jpg"
                        class="img-fluid" alt="">
                </div>
                <div class="col-xl-6 col-lg-5 pt-5 pt-lg-0">
                    <h3 class="text-dark fw-bold mb-4" data-aos="fade-up">Services</h3>
                    <div class="icon-box mb-5" data-aos="fade-up">
                        <div class="d-flex">
                            <div class="col-md-2">
                                <img class="w-75" src="/assets/img/1.svg" alt="">
                            </div>
                            <div class="col-md-10">
                                <h4 class="text-dark">Best Price Guarantee</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                            </div>
                        </div>
                    </div>

                    <div class="icon-box mb-5" data-aos="fade-up" data-aos-delay="100">
                        <div class="d-flex">
                            <div class="col-md-2">
                                <img class="w-75" src="/assets/img/2.svg" alt="">
                            </div>
                            <div class="col-md-10">
                                <h4 class="text-dark">Easy & Quick Booking</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                            </div>
                        </div>
                    </div>

                    <div class="icon-box mb-5" data-aos="fade-up" data-aos-delay="200">
                        <div class="d-flex">
                            <div class="col-md-2">
                                <img class="w-75" src="/assets/img/3.svg" alt="">
                            </div>
                            <div class="col-md-10">
                                <h4 class="text-dark">Customer Care 24/7</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </section>

    <section class="mb-5" id="sub-card-carousel">
        <div class="container" data-aos="fade-up" data-aos-offset="200" data-aos-delay="50" data-aos-duration="1000"
            data-aos-easing="ease-in-out">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                    <div class="card p-4 h-100">
                        <div class="row">
                            <h4 class="text-dark mb-3">
                                What our customers are <br> saying us?
                            </h4>
                            <p class="mb-4">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas varius
                                tortor nibh, sit
                                amet tempor nibh finibus et. Aenean eu enim justo.</p>
                        </div>
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                                <h4 class="text-dark fw-bold">13m+</h4>
                                <p>Happy People</p>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                                <h4 class="mb-0 text-dark fw-bold">4.88</h4>
                                <p class="mb-0">Overall rating</p>
                                <p><i class="fa-sharp fa-solid fa-star text-primary"></i>
                                    <i class="fa-sharp fa-solid fa-star text-primary"></i>
                                    <i class="fa-sharp fa-solid fa-star text-primary"></i>
                                    <i class="fa-sharp fa-solid fa-star text-primary"></i>
                                    <i class="fa-sharp fa-solid fa-star text-primary"></i>
                                </p>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                    <div class="card px-5 py-5 h-100">
                        <div id="carouselExampleIndicators" class="carousel slide h-100" data-bs-ride="true">
                            <!-- <div class="carousel-indicators">
                                <button class="bg-secondary" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0"
                                    class="active" aria-current="true" aria-label="Slide 1"></button>
                                <button class="bg-secondary" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1"
                                    aria-label="Slide 2"></button>
                                <button class="bg-secondary" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2"
                                    aria-label="Slide 3"></button>
                            </div> -->
                            <div class="carousel-inner h-100">
                                <div class="carousel-item h-100 sub-card-item bg-white active">
                                    <div class="row h-100">
                                        <div class="col-md-2 mt-3">
                                            <img src="/assets/img/1 (1).png" alt="">
                                        </div>
                                        <div class="col-md-10 mt-3">
                                            <p class="text-dark mb-0 p-2 fw-bold">Annette Black</p>
                                            <p>UX / UI Designer</p>
                                        </div>
                                        <div class="col-md-12 mt-5">
                                            <p class="text-dark mb-3">The place is in a great location in Gumbet. The
                                                area is
                                                safe and beautiful. The
                                                apartment was comfortable and the host was kind and responsive to our
                                                requests.</p>
                                        </div>
                                        <div class="col-md-12 d-flex justify-content-end">
                                            <button class="carousel-control-prev position-relative" type="button"
                                                data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                                                <span class="carousel-control-prev-icon text-dark"
                                                    aria-hidden="true"></span>
                                                <span class="visually-hidden">Previous</span>
                                            </button>
                                            <button class="carousel-control-next position-relative" type="button"
                                                data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                                                <span class="carousel-control-next-icon text-dark"
                                                    aria-hidden="true"></span>
                                                <span class="visually-hidden">Next</span>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="carousel-item h-100">
                                    <div class="row h-100">
                                        <div class="col-md-2 mt-3">
                                            <img src="/assets/img/1 (1).png" alt="">
                                        </div>
                                        <div class="col-md-10 mt-3">
                                            <p class="text-dark mb-0 p-2 fw-bold">Annette Black</p>
                                            <p>UX / UI Designer</p>
                                        </div>
                                        <div class="col-md-12 mt-5">
                                            <p class="text-dark">The place is in a great location in Gumbet. The area is
                                                safe and beautiful. The
                                                apartment was comfortable and the host was kind and responsive to our
                                                requests.</p>
                                        </div>
                                        <div class="col-md-12 d-flex justify-content-end">
                                            <button class="carousel-control-prev position-relative" type="button"
                                                data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                                                <span class="carousel-control-prev-icon text-dark"
                                                    aria-hidden="true"></span>
                                                <span class="visually-hidden">Previous</span>
                                            </button>
                                            <button class="carousel-control-next position-relative" type="button"
                                                data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                                                <span class="carousel-control-next-icon text-dark"
                                                    aria-hidden="true"></span>
                                                <span class="visually-hidden">Next</span>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="carousel-item h-100">
                                    <div class="row h-100">
                                        <div class="col-md-2 mt-3">
                                            <img src="/assets/img/1 (1).png" alt="">
                                        </div>
                                        <div class="col-md-10 mt-3">
                                            <p class="text-dark mb-0 p-2 fw-bold">Annette Black</p>
                                            <p>UX / UI Designer</p>
                                        </div>
                                        <div class=" col-md-12 mt-5">
                                            <p class="text-dark">The place is in a great location in Gumbet. The area is
                                                safe and beautiful. The
                                                apartment was comfortable and the host was kind and responsive to our
                                                requests.</p>
                                        </div>
                                        <div class="col-md-12 d-flex justify-content-end">
                                            <button class="carousel-control-prev position-relative" type="button"
                                                data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                                                <span class="carousel-control-prev-icon text-dark"
                                                    aria-hidden="true"></span>
                                                <span class="visually-hidden">Previous</span>
                                            </button>
                                            <button class="carousel-control-next position-relative" type="button"
                                                data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                                                <span class="carousel-control-next-icon text-dark"
                                                    aria-hidden="true"></span>
                                                <span class="visually-hidden">Next</span>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>




    <section>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                    <h4 class="text-center text-dark">Get inspiration for your next trip</h4>
                    <p class="text-center">Interdum et malesuada fames</p>
                </div>
            </div>
            <div class="row mt-3" data-aos="fade-up" data-aos-offset="200" data-aos-delay="50" data-aos-duration="1000"
                data-aos-easing="ease-in-out">
                <div class="col-lg-6 col-md-6 col-sm-6 col-12 text-center">
                    <img class="place-img w-75" src="/assets/img/1.png" alt="">
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-12 my-auto">
                    <p class="text-dark mt-3 mb-0 fw-bold">10 European ski destinations you should
                        visit this winter</p>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi, sequi maiores est similique quod
                        quidem soluta minima, adipisci molestiae ratione nesciunt alias voluptatem! Magnam sit,
                        inventore sequi molestiae in dolorem.</p>
                    <p>April 06, 2022</p>
                </div>
            </div>
            <div class="row mt-3" data-aos="fade-up" data-aos-offset="200" data-aos-delay="50" data-aos-duration="1000"
                data-aos-easing="ease-in-out">
                <div class="col-lg-6 col-md-6 col-sm-6 col-12 my-auto text-end">
                    <p class="text-dark mt-3 mb-0 fw-bold">Booking travel during Corona: good
                        advice in an uncertain time</p>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi, sequi maiores est similique quod
                        quidem soluta minima, adipisci molestiae ratione nesciunt alias voluptatem! Magnam sit,
                        inventore sequi molestiae in dolorem.</p>
                    <p>April 06, 2022</p>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-12 text-center">
                    <img class="place-img w-75" src="/assets/img/2.png" alt="">
                </div>
            </div>
            <div class="row mt-3" data-aos="fade-up" data-aos-offset="200" data-aos-delay="50" data-aos-duration="1000"
                data-aos-easing="ease-in-out">
                <div class="col-lg-6 col-md-6 col-sm-6 col-12 text-center">
                    <img class="place-img w-75" src="/assets/img/3.png" alt="">
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-12 my-auto">
                    <p class="text-dark mt-3 mb-0 fw-bold">Where can I go? 5 amazing countries
                        that are open right now</p>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi, sequi maiores est similique quod
                        quidem soluta minima, adipisci molestiae ratione nesciunt alias voluptatem! Magnam sit,
                        inventore sequi molestiae in dolorem.</p>
                    <p>April 06, 2022</p>
                </div>
            </div>
        </div>
    </section>

    <section class="mt-5">
        <div class="container">
            <div class="row">
                <h3 class="text-dark fw-bold text-center">Destinations we love</h3>
                <p class="text-center">Interdum et malesuada fames ac ante ipsum</p>
            </div>
            <div class="row my-2">
                <div class="col-lg-12 d-flex justify-content-center">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="home-tab" data-bs-toggle="tab"
                                data-bs-target="#home-tab-pane" type="button" role="tab" aria-controls="home-tab-pane"
                                aria-selected="true">Regions</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="profile-tab" data-bs-toggle="tab"
                                data-bs-target="#profile-tab-pane" type="button" role="tab"
                                aria-controls="profile-tab-pane" aria-selected="false">Cities</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="contact-tab" data-bs-toggle="tab"
                                data-bs-target="#contact-tab-pane" type="button" role="tab"
                                aria-controls="contact-tab-pane" aria-selected="false">Places of
                                interest</button>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="row my-3">
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active mt-3" id="home-tab-pane" role="tabpanel"
                        aria-labelledby="home-tab" tabindex="0">
                        <div id="services">
                            <div class="container" data-aos="fade-up">
                                <div class="row">
                                    <?php  foreach ($countries as $key => $value) { ?>
                                    <div class="col-lg-3 col-md-6" data-aos="zoom-in">
                                        <div class="box">
                                            <div class="icon">
                                                <i class="fa-solid fa-location-dot"></i>
                                            </div>
                                            <h4 class="title"><a href="<?php echo base_url().$franhisurl.$value->country_slug."-toursit-guide" ?>"><?=$value->name?></a></h4>
                                            <p class="description">12,683 properties</p>
                                        </div>
                                    </div>
                                   <?php } ?>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade mt-3" id="profile-tab-pane" role="tabpanel" aria-labelledby="profile-tab"
                        tabindex="0">
                        <div id="services">
                            <div class="container" data-aos="fade-up">
                                <div class="row">
                                    <div class="col-lg-3 col-md-6" data-aos="zoom-in">
                                        <div class="box">
                                            <div class="icon">
                                                <i class="fa-solid fa-location-dot"></i>
                                            </div>
                                            <h4 class="title"><a href="">Hawai</a></h4>
                                            <p class="description">12,683 properties</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-6" data-aos="zoom-in">
                                        <div class="box">
                                            <div class="icon">
                                                <i class="fa-solid fa-location-dot"></i>
                                            </div>
                                            <h4 class="title"><a href="">Istanbul</a></h4>
                                            <p class="description">12,683 properties</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-6" data-aos="zoom-in">
                                        <div class="box">
                                            <div class="icon">
                                                <i class="fa-solid fa-location-dot"></i>
                                            </div>
                                            <h4 class="title"><a href="">San Diego</a></h4>
                                            <p class="description">12,683 properties</p>
                                        </div>
                                    </div>

                                    <div class="col-lg-3 col-md-6" data-aos="zoom-in">
                                        <div class="box">
                                            <div class="icon">
                                                <i class="fa-solid fa-location-dot"></i>
                                            </div>
                                            <h4 class="title"><a href="">Phuket</a></h4>
                                            <p class="description">12,683 properties</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-6" data-aos="zoom-in">
                                        <div class="box">
                                            <div class="icon">
                                                <i class="fa-solid fa-location-dot"></i>
                                            </div>
                                            <h4 class="title"><a href="">Reykjavik</a></h4>
                                            <p class="description">12,683 properties</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-6" data-aos="zoom-in">
                                        <div class="box">
                                            <div class="icon">
                                                <i class="fa-solid fa-location-dot"></i>
                                            </div>
                                            <h4 class="title"><a href="">Santorini</a></h4>
                                            <p class="description">12,683 properties</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-6" data-aos="zoom-in">
                                        <div class="box">
                                            <div class="icon">
                                                <i class="fa-solid fa-location-dot"></i>
                                            </div>
                                            <h4 class="title"><a href="">Los Angeles</a></h4>
                                            <p class="description">12,683 properties</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-6" data-aos="zoom-in">
                                        <div class="box">
                                            <div class="icon">
                                                <i class="fa-solid fa-location-dot"></i>
                                            </div>
                                            <h4 class="title"><a href="">İbiza</a></h4>
                                            <p class="description">12,683 properties</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-6" data-aos="zoom-in">
                                        <div class="box">
                                            <div class="icon">
                                                <i class="fa-solid fa-location-dot"></i>
                                            </div>
                                            <h4 class="title"><a href="">Boston</a></h4>
                                            <p class="description">12,683 properties</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-6" data-aos="zoom-in">
                                        <div class="box">
                                            <div class="icon">
                                                <i class="fa-solid fa-location-dot"></i>
                                            </div>
                                            <h4 class="title"><a href="">Florence</a></h4>
                                            <p class="description">12,683 properties</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-6" data-aos="zoom-in">
                                        <div class="box">
                                            <div class="icon">
                                                <i class="fa-solid fa-location-dot"></i>
                                            </div>
                                            <h4 class="title"><a href="">Mykonos</a></h4>
                                            <p class="description">12,683 properties</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-6" data-aos="zoom-in">
                                        <div class="box">
                                            <div class="icon">
                                                <i class="fa-solid fa-location-dot"></i>
                                            </div>
                                            <h4 class="title"><a href="">London</a></h4>
                                            <p class="description">12,683 properties</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-6" data-aos="zoom-in">
                                        <div class="box">
                                            <div class="icon">
                                                <i class="fa-solid fa-location-dot"></i>
                                            </div>
                                            <h4 class="title"><a href="">Paris</a></h4>
                                            <p class="description">12,683 properties</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-6" data-aos="zoom-in">
                                        <div class="box">
                                            <div class="icon">
                                                <i class="fa-solid fa-location-dot"></i>
                                            </div>
                                            <h4 class="title"><a href="">Dubai</a></h4>
                                            <p class="description">12,683 properties</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-6" data-aos="zoom-in">
                                        <div class="box">
                                            <div class="icon">
                                                <i class="fa-solid fa-location-dot"></i>
                                            </div>
                                            <h4 class="title"><a href="">Krakow</a></h4>
                                            <p class="description">12,683 properties</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-6" data-aos="zoom-in">
                                        <div class="box">
                                            <div class="icon">
                                                <i class="fa-solid fa-location-dot"></i>
                                            </div>
                                            <h4 class="title"><a href="">Jersey</a></h4>
                                            <p class="description">12,683 properties</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-6" data-aos="zoom-in">
                                        <div class="box">
                                            <div class="icon">
                                                <i class="fa-solid fa-location-dot"></i>
                                            </div>
                                            <h4 class="title"><a href="">Prag</a></h4>
                                            <p class="description">12,683 properties</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-6" data-aos="zoom-in">
                                        <div class="box">
                                            <div class="icon">
                                                <i class="fa-solid fa-location-dot"></i>
                                            </div>
                                            <h4 class="title"><a href="">Amsterdam</a></h4>
                                            <p class="description">12,683 properties</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-6" data-aos="zoom-in">
                                        <div class="box">
                                            <div class="icon">
                                                <i class="fa-solid fa-location-dot"></i>
                                            </div>
                                            <h4 class="title"><a href="">Rome</a></h4>
                                            <p class="description">12,683 properties</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-6" data-aos="zoom-in">
                                        <div class="box">
                                            <div class="icon">
                                                <i class="fa-solid fa-location-dot"></i>
                                            </div>
                                            <h4 class="title"><a href="">Miami</a></h4>
                                            <p class="description">12,683 properties</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade mt-3" id="contact-tab-pane" role="tabpanel" aria-labelledby="contact-tab"
                        tabindex="0">
                        <div id="services">
                            <div class="container" data-aos="fade-up">
                                <div class="row">
                                    <?php foreach ($places_data as $key => $place) { ?>
                                    <div class="col-lg-3 col-md-6" data-aos="zoom-in">
                                        <div class="box">
                                            <div class="icon">
                                                <i class="fa-solid fa-location-dot"></i>
                                            </div>
                                            <h4 class="title"><?=$place->i_name?></h4>
                                            <p class="description">12,683 properties</p>
                                        </div>
                                    </div>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- service section -->
        </div>
    </section>
    <section class="layout-pt-md layout-pb-md py-5" style="background-color: #0d2857;">
        <div class="container">
            <div class="row y-gap-30 justify-content-center items-center">
                <div class="col-auto">
                    <div class="row y-gap-20  flex-wrap items-center">
                        <div class="col-lg-8 col-md-6 col-sm-6 col-12">
                            <img src="https://cdn.pixabay.com/photo/2018/03/22/02/37/email-3249062_1280.png" alt="">
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-12 my-auto">
                            <h4 class=" text-white">Your Travel Journey Starts Here</h4>
                            <div class="text-white mt-2">Sign up and we'll send the best deals to you</div>
                            <div class="d-flex mt-3">
                                <div class="col text-end ">
                                    <input class="bg-white h-75  form-control h-100" type="text"
                                        placeholder="Your Email">
                                </div>

                                <div class="col-auto  my-0">
                                    <button class="button h-60 bg-blue-1 text-white my-0">Subscribe</button>
                                </div>
                            </div>
                        </div>
                        <!-- <div class="col-auto">
                  <div class="icon-newsletter text-60 sm:text-40 text-white"></div>
                </div>
  
                <div class="col-auto">
                  
                </div>
              </div>
            </div>
  
            <div class="col-12">
                <div class="row justify-content-center">
                    <div class="col text-end ">
                      <input class="bg-white h-75 w-75 form-control h-100" type="text" placeholder="Your Email">
                    </div>
      
                    <div class="col  my-0">
                      <button class="button h-60 bg-blue-1 text-white my-0">Subscribe</button>
                    </div>
                </div>
              </div> -->
                    </div>
                </div>
            </div>
    </section>

    <section>
        <div class="footer mt-3">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-3 mb-3">
                        <div class="aboutme" data-aos="fade-up" data-aos-offset="200" data-aos-delay="50"
                            data-aos-duration="1000" data-aos-easing="ease-in-out">
                            <div class="aboutme-content">
                                <h5>About Me</h5>
                                <div class="textwidgets">
                                    <p> Start writing, no matter what. The water does not flow until the faucet is
                                        turned on.</p>
                                    
                                        <?php if($franchisdetail[0]->contact_address != ""){ ?>
                                       <p><strong>Address</strong><br>
                                       <?=$franchisdetail[0]->contact_address?>
                                    <?php } ?>
                                    <p>Follow me</p>
                                    <ul class="ps-0">
                                        <?php if($franchisdetail[0]->facebook != ""){ ?>
                                        <li class="list-inline-item"><a class="fb" href="<?=$franchisdetail[0]->facebook?>" target="_blank"
                                                title="Facebook"><i class="fa-brands fa-facebook-square"></i></a></li>
                                        <?php } ?> 
                                        <?php if($franchisdetail[0]->twitter != ""){ ?>
                                         <li class="list-inline-item"><a class="fb" href="<?=$franchisdetail[0]->twitter?>" target="_blank"
                                                title="Facebook"><i class="fa-brands fa-twitter-square"></i></a></li>
                                        <?php } ?>
                                        <?php if($franchisdetail[0]->linkedinlink != ""){ ?>
                                         <li class="list-inline-item"><a class="fb" href="<?=$franchisdetail[0]->linkedinlink?>" target="_blank"
                                                title="Facebook"><i class="fa-brands fa-linkedin"></i></a></li>
                                        <?php } ?> 
                                         <?php if($franchisdetail[0]->youtube != ""){ ?>
                                         <li class="list-inline-item"><a class="fb" href="<?=$franchisdetail[0]->youtube?>" target="_blank"
                                                title="Facebook"><i class="fa-brands fa-youtube-square"></i></a></li>
                                        <?php } ?> 
                                         <?php if($franchisdetail[0]->instagram != ""){ ?>
                                         <li class="list-inline-item"><a class="fb" href="<?=$franchisdetail[0]->instagram?>" target="_blank"
                                                title="Facebook"><i class="fa-brands fa-instagram"></i></a></li>
                                        <?php } ?>        
                                        

                                    </ul>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-md-6 col-lg-2 mb-3">
                        <div class="aboutme" data-aos="fade-up" data-aos-offset="200" data-aos-delay="50"
                            data-aos-duration="1000" data-aos-easing="ease-in-out">
                            <div class="aboutme-content">
                                <h5>Quick Link</h5>
                                <ul class="ps-0 font-small">
                                    <li class="list-inline-item"><a class="fb" href="#" target="_blank"
                                            title="Facebook">About me</a></li>
                                    <li class="list-inline-item"><a class="fb" href="#" target="_blank"
                                            title="Facebook">Help & Support</a></li>
                                    <li class="list-inline-item"><a class="fb" href="#" target="_blank"
                                            title="Facebook">Licensing Policy</a></li>
                                    <li class="list-inline-item"><a class="fb" href="#" target="_blank"
                                            title="Facebook">Refund Policy</a></li>
                                    <li class="list-inline-item"><a class="fb" href="#" target="_blank"
                                            title="Facebook">Hire me</a></li>
                                    <li class="list-inline-item"><a class="fb" href="#" target="_blank"
                                            title="Facebook">Contact</a></li>
                                </ul>
                            </div>
                        </div>

                    </div>
                    <div class="col-md-6 col-lg-3 mb-3">
                        <div class="aboutme" data-aos="fade-up" data-aos-offset="200" data-aos-delay="50"
                            data-aos-duration="1000" data-aos-easing="ease-in-out" data-aos-duration="1000"
                            data-aos-easing="ease-in-out">
                            <div class="aboutme-content">
                                <h5>TagCloud</h5>
                                <div class="tagcloud">
                                    <a href="">Beautiful</a>
                                    <a href="">New York</a>
                                    <a href="">Droll</a>
                                    <a href="">Intimate</a>
                                    <a href="">Loving</a>
                                    <a href="">Travel</a>
                                    <a href="">Fighting</a>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="col-md-6 col-lg-4 mb-3">
                        <div class="aboutme" data-aos="fade-up" data-aos-offset="200" data-aos-delay="50"
                            data-aos-duration="1000" data-aos-easing="ease-in-out">
                            <div class="aboutme-content">
                                <h5>NewsLetter</h5>
                                <p>Subscribe to our newsletter and get our newest updates right on your inbox.</p>
                                <form class="form mt-4 w-100">
                                    <div class="d-flex flex-lg-row flex-md-row flex-sm-row flex-column">
                                        <input type="email" placeholder="Enter your email"
                                            class="form-control mb-lg-0 mb-md-0 mb-sm-0 mb-3">
                                        <button class="btn text-white kv-btn-primary">Subscribe</button>

                                    </div>
                                    <div class="d-flex">
                                        <input class="w-auto" type="checkbox" style="width: 100%;"> I agree to the <span>terms &amp; conditions</span>
                                    </div>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>







    <script src="<?php echo base_url(); ?>assets/fronted/index.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.0.0/mdb.min.js"></script>

    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>
    <!-- End Example Code -->
</body>

</html>