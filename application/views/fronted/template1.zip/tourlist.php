<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.2/assets/css/docs.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
    <!-- MDB -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.0.0/mdb.min.css" rel="stylesheet" />
    <title>Document</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <link type="text/css" rel="stylesheet" href="<?php echo base_url(); ?>assets/fronted/style.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/fronted/swiper-bundle.min.css">
    <script src="<?php echo base_url(); ?>assets/fronted/swiper-bundle.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/fronted/main.js"></script>

    <script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />

    

</head>

<body class="m-0 border-0">
    <!-- Example Code -->
    <div class="accordion" id="accordionExample">
        <div class="accordion-item">
            <nav class="navbar sticky-top navbar-expand-xl bg-light">
                <div class="container-fluid">
                    <a class="navbar-brand fw-bold ms-3" href="#">
                    	<?php if($franchisdetail[0]->logo != ""){ ?>
                    		<img src="<?php echo base_url().$franchisdetail[0]->logo ?>" width="50" height="60" />
                    	<?php }else{ ?>	
                    		LOGO
                    	<?php } ?>	
                    </a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse-md navbar-collapse-sm navbar-collapse"
                        id="navbarSupportedContent">
                        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                            <li class="nav-item  my-auto">
                                <a class="nav-link active" aria-current="page" href="#">
                                    <button class="btn px-1 shadow-none nav-button">
                                        <i class="fa-solid fa-house-chimney pe-0"></i> Home
                                    </button>
                                </a>
                            </li>
                            <li class="nav-item  my-auto py-2">
                                <div class="dropdown">
                                    <button class="btn px-2 bg-light nav-button dropdown-toggle shadow-none my-auto"
                                        type="button" id="dropdownMenuButton" data-mdb-toggle="dropdown"
                                        aria-expanded="false">
                                        Free Zone Companies
                                    </button>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <li>
                                            <a class="dropdown-item" href="#">
                                                <div class="row">
                                                    <div class="col-6">Option 1</div>
                                                    <div class="col-6 text-end"> &rsaquo;</div>
                                                </div>
                                            </a>
                                            <ul class="dropdown-menu dropdown-submenu">
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 1</a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 2</a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 3</a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 4</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="#">
                                                <div class="row">
                                                    <div class="col-6">Option 2</div>
                                                    <div class="col-6 text-end"> &rsaquo;</div>
                                                </div>
                                            </a>
                                            <ul class="dropdown-menu dropdown-submenu">


                                                <li>
                                                    <a class="dropdown-item" href="#">Option 1</a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 2</a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 3</a>
                                                </li>

                                                <li>
                                                    <a class="dropdown-item" href="#">Option 4
                                                    </a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="#">
                                                <div class="row">
                                                    <div class="col-6">Option 3</div>
                                                    <div class="col-6 text-end"> &rsaquo;</div>
                                                </div>
                                            </a>
                                            <ul class="dropdown-menu dropdown-submenu">

                                                <li>
                                                    <a class="dropdown-item" href="#">Option 1</a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 2
                                                    </a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 3
                                                    </a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 4
                                                    </a>
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item  my-auto py-2">
                                <div class="dropdown">
                                    <button class="btn px-2 bg-light nav-button dropdown-toggle shadow-none my-auto"
                                        type="button" id="dropdownMenuButton" data-mdb-toggle="dropdown"
                                        aria-expanded="false">
                                        USA Food
                                    </button>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <li>
                                            <a class="dropdown-item" href="#">
                                                <div class="row">
                                                    <div class="col-6">Option 1</div>
                                                    <div class="col-6 text-end"> &rsaquo;</div>
                                                </div>
                                            </a>
                                            <ul class="dropdown-menu dropdown-submenu">
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 1</a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 2</a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 3</a>
                                                </li>

                                                <li>
                                                    <a class="dropdown-item" href="#">Option 4</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="#">
                                                <div class="row">
                                                    <div class="col-6">Option 2</div>
                                                    <div class="col-6 text-end"> &rsaquo;</div>
                                                </div>
                                            </a>
                                            <ul class="dropdown-menu dropdown-submenu">
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 1</a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 2</a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 3</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="#">
                                                <div class="row">
                                                    <div class="col-6">Option 3</div>
                                                    <div class="col-6 text-end"> &rsaquo;</div>
                                                </div>
                                            </a>
                                            <ul class="dropdown-menu dropdown-submenu">

                                                <li>
                                                    <a class="dropdown-item" href="#">Option 1</a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 2
                                                    </a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 3
                                                    </a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="#">Option 4
                                                    </a>
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item  my-auto">
                                <a class="nav-link " aria-current="page" href="#">
                                    <button class="btn px-1 nav-button shadow-none">
                                        About
                                    </button>
                                </a>
                            </li>
                            <li class="nav-item  my-auto">
                                <a class="nav-link " aria-current="page" href="#">
                                    <button class="btn px-1 nav-button shadow-none">
                                        Contact
                                    </button>
                                </a>
                            </li>
                            <li class="nav-item  my-auto">
                                <a class="nav-link " aria-current="page" href="#">
                                    <button class="btn px-1 nav-button shadow-none">
                                        Privacy Policy
                                    </button>
                                </a>
                            </li>
                            <li class="nav-item  my-auto">
                                <a class="nav-link " aria-current="page" href="#">
                                    <button class="btn px-1 nav-button  shadow-none">
                                        Call on 1234567890
                                    </button>
                                </a>
                            </li>
                            <li class="nav-item  my-auto">
                                <button class=" btn px-1 bg-light nav-button shadow-none collapsed"
                                    onclick="expandCollapseExpansionPanel()" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                                    <i class="fa-solid fa-magnifying-glass me-2"></i>Search
                                </button>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <div id="collapseTwo" class="accordion-collapse collapse h-100" aria-labelledby="headingOne"
                data-bs-parent="#accordionExample">
                <div class="accordion-body">
                    <div class="row">
                        <div class="col-md-8 offset-md-2">
                            <h1 class="text-center text-secondary my-3">SEARCH</h1>
                            <div class="input-group mt-3">
                                <input type="text" class="form-control border-0 "
                                    placeholder="Search stories, places and people"
                                    aria-label="Search stories, places and people" aria-describedby="basic-addon2">
                                <div class="input-group-append">
                                    <span class="input-group-text border-0 " id="basic-addon2">
                                        <i class="fa-solid fa-magnifying-glass me-2"></i>
                                    </span>
                                </div>
                            </div>
                            <hr class="border-4 border-dark my-0">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

  
  <div class="clearfix" ></div>
  
  <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="false">
        <div class="carousel-indicators text-center d-block">
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0"
                class="active text-white" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" class="text-white"
                aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" class="text-white"
                aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner rounded-0">
            <div class="carousel-item rounded-0  active" style="height: 450px;">
                <img src="https://cdn.pixabay.com/photo/2019/03/09/21/30/downtown-4045036_1280.jpg"
                    class="d-block w-100 carousel-img" alt="...">
                <div class="carousel-caption text-center text-white ">
                    <h5 class="text-white">First slide label</h5>
                    <p class="text-white">Some representative placeholder content for the first slide.</p>
                </div>
            </div>
            <div class="carousel-item rounded-0 " style="height: 450px;">
                <img src="https://cdn.pixabay.com/photo/2017/04/08/10/42/burj-khalifa-2212978_1280.jpg"
                    class="d-block w-100 carousel-img" alt="...">
                <div class="carousel-caption text-center text-white ">
                    <h5 class="text-white">Second slide label</h5>
                    <p class="text-white">Some representative placeholder content for the second slide.</p>
                </div>
            </div>
            <div class="carousel-item rounded-0 " style="height: 450px;">
                <img src="https://cdn.pixabay.com/photo/2016/10/24/22/43/dubai-1767540_1280.jpg"
                    class="d-block w-100 carousel-img" alt="...">
                <div class="carousel-caption text-center text-white ">
                    <h5 class="text-white">Third slide label</h5>
                    <p class="text-white">Some representative placeholder content for the third slide.</p>
                </div>
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
            data-bs-slide="prev">
            <span class="carousel-control-prev-icon text-white" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
            data-bs-slide="next">
            <span class="carousel-control-next-icon text-white" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>

    <section>
        <div class="container mt-3 content">
            <div class="row" data-aos="fade-up" data-aos-offset="200" data-aos-delay="50" data-aos-duration="1000"
                data-aos-easing="ease-in-out">
                <div class="col-12 col-sm-12 col-md-12 col-lg-12 mt-4">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <h2 class="text-dark ">Start your holiday today</h2>
                        </div>
                    </div>
                </div>

                <div class="col-md-12 col-lg-8 mt-4" data-aos="fade-up ">
                    <img src="<?php echo base_url(); ?>/assets/images/new-places-to-visit-header-v2.webp"
                        class=" zoom-out d-block carousel-img w-100 rounded" alt="...">
                </div>
                <div class="col-md-6 col-lg-4 mt-4 position-relative" data-aos="fade-up ">
                    <div class="card  cardtokyo h-100" style="padding-bottom: 30px;" data-aos="fade-up"
                        data-aos-offset="200" data-aos-delay="50" data-aos-duration="1000"
                        data-aos-easing="ease-in-out">

                        <div class="px-4 mt-2 py-0 mb-0">
                            <span><a href="" class="text-decoration-none text-info fw-bold mb-0">Sports <span
                                        class="dot">.</span></a></span>
                        </div>
                        <div class="px-4">
                            <p>
                            <h4 class="card-description card-content px-0 pb-3">New attractions to check out in Dubai
                            </h4>
                            Discover hot new openings and fresh experiences that you will love.
                            </p>
                        </div>
                        <div class="px-4 mb-3 mt-auto row">
                            <div class="col-6">
                                <button class="btn btn-secondary border-0 card-link">
                                    Read now >
                                </button>
                            </div>
                            <div class="col-6">
                                <button class=" like-btn-2 btn card-link  ">
                                    <i class="fa-regular fa-heart fa-2x"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>




    <section class="swiper my-5">
        <div class="container" data-aos="fade-up " data-aos-offset="200" data-aos-delay="50" data-aos-duration="1000"
            data-aos-easing="ease-in-out">
            <div class="slide-container swiper">
                <div class="slide-content">
                    <div class="card-wrapper swiper-wrapper">
                        <?php  
                    if(!empty($places_data)) { $i = 1;
                    foreach ($places_data as $key => $value) { 
                        if($value->img_name == ""){
                                   $image = "https://cdn.pixabay.com/photo/2019/03/09/21/30/downtown-4045036_1280.jpg";
                                }else{
                                    $image = "http://".$_SERVER["HTTP_HOST"]."/visaclaptour/".$value->img_name; 
                                }
                        ?>    
                        <div class="card swiper-slide mb-2" data-aos="fade-up " data-aos-offset="200"
                            data-aos-delay="50" data-aos-duration="1000" data-aos-easing="ease-in-out">
                            <div class="image-content pt-0">
                                <img class="sub-img zoom-out" src="<?php echo $image; ?>">
                            </div>
                            <h4 class="card-description card-content px-4"><?= $value->i_name ?></h4>
                            </p>
                        </div>
                      <?php } } ?>  
                    </div>
                </div>
                <div class="swiper-button-next text-secondary swiper-navBtn d-lg-block d-md-block d-sm-block d-none"></div>
                <div class="swiper-button-prev text-secondary swiper-navBtn d-lg-block d-md-block d-sm-block d-none"></div>
                <div class="swiper-pagination d-lg-none d-md-none d-sm-none d-block"></div>
            </div>
        </div>
        </div>


        </div>
    </section>


    <section id="gallery">
        <div class="container my-5">
            <div class="d-lg-flex d-md-flex d-sm-flex flex-nowrap" data-aos="fade-up " data-aos-offset="200"
                data-aos-delay="50" data-aos-duration="1000" data-aos-easing="ease-in-out">
                <ul data-aos="fade-up " data-aos-offset="200" data-aos-delay="50" data-aos-duration="1000"
                    data-aos-easing="ease-in-out" class="nav nav-tabs flex-lg-column  flex-md-column flex-sm-column
                flex-lg-wrap flex-md-wrap flex-sm-wrap flex-nowrap tabs-header" id="myTab" role="tablist">
                    
                   
                    <?php  
                    if(!empty($category_data)) { $i = 1;
                         
                    foreach ($category_data as $key => $value) { 
                        $slug = str_replace(' ', '-', $value->name);
                        ?>
                    <li class="nav-item " role="presentation">
                        <button class="nav-link w-100 h-100 text-nowrap cursor-pointer position-relative  <?php echo ($i == 1) ? "active" : ""; ?>"
                            id="<?=$value->cat_slug?>-tab" data-bs-toggle="tab" data-bs-target="#<?=$value->cat_slug?>" type="button" role="tab"
                            aria-controls="" aria-selected="false"><?=$value->name?></button>
                    </li>
                    <?php $i++; } }?>
                </ul>
                <div class="tab-content ms-lg-3 ms-md-3 ms-sm-3 ms-0 mt-lg-0 mt-md-0 mt-sm-0 mt-3 w-100 "
                    id="myTabContent">
                    <?php  
                    if(!empty($tourist_data)) {  $j=1;
                    foreach ($tourist_data as $key => $value) { 
                        $slug = str_replace(' ', '-', $key);
                    ?>
                    <div class=" h-100 tab-pane fade show <?php echo ($j == 1) ? "active" : ""; ?>" id="<?php echo $slug ?>" role="tabpanel"
                        aria-labelledby="<?php echo $slug ?>-tab">
                        <div class="h-100 row align-items-center bg-light">
                            <h1 class="text-secondary"><?php echo $key; ?></h1>
                            <?php  
                            if(!empty($value)) { 
                                $e = 1;
                            foreach ($value as $key1 => $data) { 
                                if($data->img_name == ""){
                                   $image = base_url()."assets/3.png";
                                }else{
                                    $image = "http://".$_SERVER["HTTP_HOST"]."/visaclaptour/".$data->img_name; 
                                }
                                ?>
                            <div class=" col-lg-4 col-md-4 col-sm-6 col-12 my-2 ">
                                <div class="card"></div>
                                <img src="<?=$image?>"
                                    alt="" class="rounded-4 gallery-image">
                            </div>
                                  
                            <?php  } } ?>
                            <a class="btn card-link " href="<?php echo base_url().$franhisurl.$value[0]->country_slug."/".$slug ?>" style="float: right;text-align: right;">View All</a>   
                        </div>
                                    
                     </div>
                     <?php  $j++; } } ?>
                </div>
            </div>
        </div>
    </section>
    
    <section>
        <div class="footer mt-3">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-lg-3 mb-3">
                        <div class="aboutme" data-aos="fade-up" data-aos-offset="200" data-aos-delay="50"
                            data-aos-duration="1000" data-aos-easing="ease-in-out">
                            <div class="aboutme-content">
                                <h5>About Me</h5>
                                <div class="textwidgets">
                                    <p> Start writing, no matter what. The water does not flow until the faucet is
                                        turned on.</p>
                                    <p><strong>Address</strong><br>
                                        123 Main Street<br>
                                        New York, NY 1001</p>
                                    <p>Follow me</p>
                                    <ul class="ps-0">
                                        <li class="list-inline-item"><a class="fb" href="#" target="_blank"
                                                title="Facebook"><i class="fa-brands fa-facebook"></i></a></li>
                                        <li class="list-inline-item"><a class="fb" href="#" target="_blank"
                                                title="Facebook"><i class="fa-brands fa-twitter"></i></a></li>
                                        <li class="list-inline-item"><a class="fb" href="#" target="_blank"
                                                title="Facebook"><i class="fa-brands fa-pinterest"></i></a></li>

                                    </ul>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-md-6 col-lg-2 mb-3">
                        <div class="aboutme" data-aos="fade-up" data-aos-offset="200" data-aos-delay="50"
                            data-aos-duration="1000" data-aos-easing="ease-in-out">
                            <div class="aboutme-content">
                                <h5>Quick Link</h5>
                                <ul class="ps-0 font-small">
                                    <li class="list-inline-item"><a class="fb" href="#" target="_blank"
                                            title="Facebook">About me</a></li>
                                    <li class="list-inline-item"><a class="fb" href="#" target="_blank"
                                            title="Facebook">Help & Support</a></li>
                                    <li class="list-inline-item"><a class="fb" href="#" target="_blank"
                                            title="Facebook">Licensing Policy</a></li>
                                    <li class="list-inline-item"><a class="fb" href="#" target="_blank"
                                            title="Facebook">Refund Policy</a></li>
                                    <li class="list-inline-item"><a class="fb" href="#" target="_blank"
                                            title="Facebook">Hire me</a></li>
                                    <li class="list-inline-item"><a class="fb" href="#" target="_blank"
                                            title="Facebook">Contact</a></li>
                                </ul>
                            </div>
                        </div>

                    </div>
                    <div class="col-md-6 col-lg-3 mb-3">
                        <div class="aboutme" data-aos="fade-up" data-aos-offset="200" data-aos-delay="50"
                            data-aos-duration="1000" data-aos-easing="ease-in-out" data-aos-duration="1000"
                            data-aos-easing="ease-in-out">
                            <div class="aboutme-content">
                                <h5>TagCloud</h5>
                                <div class="tagcloud">
                                    <a href="">Beautiful</a>
                                    <a href="">New York</a>
                                    <a href="">Droll</a>
                                    <a href="">Intimate</a>
                                    <a href="">Loving</a>
                                    <a href="">Travel</a>
                                    <a href="">Fighting</a>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="col-md-6 col-lg-4 mb-3">
                        <div class="aboutme" data-aos="fade-up" data-aos-offset="200" data-aos-delay="50"
                            data-aos-duration="1000" data-aos-easing="ease-in-out">
                            <div class="aboutme-content">
                                <h5>NewsLetter</h5>
                                <p>Subscribe to our newsletter and get our newest updates right on your inbox.</p>
                                <form class="form mt-4 w-100">
                                    <div class="d-flex flex-lg-row flex-md-row flex-sm-row flex-column">
                                        <input type="email" placeholder="Enter your email"
                                            class="form-control mb-lg-0 mb-md-0 mb-sm-0 mb-3">
                                        <button class="btn text-white kv-btn-primary">Subscribe</button>

                                    </div>
                                    <div class="d-flex">
                                        <input class="w-auto" type="checkbox" style="width: 100%;"> I agree to the <span>terms &amp; conditions</span>
                                    </div>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>







    <script src="<?php echo base_url(); ?>assets/fronted/index.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.0.0/mdb.min.js"></script>

    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>
    <!-- End Example Code -->
</body>

</html>